// RFL fragment cut-map preparation worker.
// Self-contained Blob module for the standalone HTML. Host ABI alias: dne.
// Keep allocation and messaging out of the render hot path.
const dne=String.raw`
function _(e) {
    return e.buffer instanceof ArrayBuffer && e.byteOffset === 0 && e.byteLength === e.buffer.byteLength;
}

function I(e, r, a, n, c = !1) {
    if (!e || e.version !== 1 || e.sourceId !== n || !Number.isInteger(n) || n < 1 || a < 2 || a > 1048576 || r < 8e3 || r > 192e3 || !Number.isFinite(r) || e.sr !== r || e.n !== a || e.duration !== a / r || e.hop !== Math.max(24, Math.min(128, Math.round(r * .0012))) || !(e.base instanceof Float64Array) || e.base.length !== a || !(e.cross instanceof Uint8Array) || e.cross.length !== a || !_(e.base) || !_(e.cross)) return !1;
    let u = Math.ceil(a / e.hop), h = [ e.amp, e.slope, e.energy, e.peak ];
    for (let o of h) if (!(o instanceof Float32Array) || o.length !== u || !_(o)) return !1;
    if (c) {
        for (let o = 0; o < a; o++) if (!Number.isFinite(e.base[o]) || e.cross[o] > 1) return !1;
        for (let o of h) for (let m = 0; m < o.length; m++) if (!Number.isFinite(o[m])) return !1;
    }
    return !0;
}

var k = (e, r, a) => Math.max(r, Math.min(a, e)), R = (e, r) => 1 - k(Math.abs(e) / Math.max(1e-4, r), 0, 1);

function S(e, r, a) {
    if (!Array.isArray(e) || e.length < 1 || e.length > 2 || !(e[0] instanceof Float32Array) || !Number.isFinite(r) || r < 8e3 || r > 192e3 || !Number.isInteger(a) || a < 1) throw new Error("fragment-pcm-descriptor");
    let n = e[0].length;
    if (n < 2 || n > 1048576) throw new Error("fragment-frame-cap");
    for (let t of e) {
        if (!(t instanceof Float32Array) || t.length !== n) throw new Error("fragment-channel-length");
        for (let s = 0; s < n; s++) if (!Number.isFinite(t[s]) || Math.abs(t[s]) > 16) throw new Error("fragment-pcm-domain");
    }
    let c = t => {
        t = k(t, 0, n - 1);
        let s = 0;
        for (let f = 0; f < e.length; f++) s += e[f][t] ?? 0;
        return s / e.length;
    }, u = Math.max(24, Math.min(128, Math.round(r * .0012))), h = Math.max(1, Math.ceil(n / u)), o = new Float32Array(h), m = new Float32Array(h), E = new Float32Array(h), N = new Float32Array(h), T = 0;
    for (let t = 0; t < h; t++) {
        let s = Math.min(n - 1, t * u), f = Math.max(12, Math.min(96, Math.floor(u * .85))), A = Math.max(0, s - f), p = Math.min(n - 1, s + f), l = 0, b = 0, g = 0, i = 0;
        for (let M = 0; M < e.length; M++) {
            l += e[M][s] ?? 0;
            for (let w = A; w <= p; w++) {
                let x = e[M][w] ?? 0;
                b += x * x, i = Math.max(i, Math.abs(x)), g++;
            }
        }
        l /= e.length, o[t] = Math.abs(l), m[t] = Math.abs(l - T), E[t] = Math.sqrt(b / Math.max(1, g)),
        N[t] = i, T = l;
    }
    let B = new Float64Array(n), v = new Uint8Array(n), F = Math.max(6, Math.min(96, Math.round(r * 75e-5)));
    for (let t = 0; t < n; t++) {
        let s = c(t), f = c(Math.max(0, t - 1)), A = c(Math.min(n - 1, t + 1)), p = Math.abs(A - f) * .5, l = 0, b = 0, g = 0;
        for (let i = Math.max(0, t - F); i <= Math.min(n - 1, t + F); i += Math.max(1, Math.floor(F / 12))) {
            let M = c(i);
            l += M * M, b = Math.max(b, Math.abs(M)), g++;
        }
        B[t] = R(s, .035) * .31 + R(Math.sqrt(l / Math.max(1, g)), .12) * .18 + R(b, .22) * .11 + R(p, .055) * .19,
        v[t] = f <= 0 && A >= 0 || f >= 0 && A <= 0 ? 1 : 0;
    }
    return {
        version: 1,
        sourceId: a,
        sr: r,
        n: n,
        duration: n / r,
        hop: u,
        amp: o,
        slope: m,
        energy: E,
        peak: N,
        base: B,
        cross: v
    };
}

var y = globalThis, d = !1;

function G(e, r) {
    return [ ...e.map(a => a.buffer), r.amp.buffer, r.slope.buffer, r.energy.buffer, r.peak.buffer, r.base.buffer, r.cross.buffer ];
}

y.onmessage = e => {
    let r = e.data;
    if (!(d || r?.type !== "prepare")) {
        d = !0;
        try {
            let a = S(r.channels, r.sampleRate, r.sourceId);
            if (!I(a, r.sampleRate, r.channels[0].length, r.sourceId, !0)) throw new Error("fragment-map-values");
            y.postMessage({
                type: "prepared",
                session: r.session,
                token: r.token,
                asset: r.asset,
                sourceId: r.sourceId,
                sampleRate: r.sampleRate,
                channels: r.channels,
                map: a
            }, G(r.channels, a));
        } catch (a) {
            y.postMessage({
                type: "fault",
                session: r.session,
                token: r.token,
                asset: r.asset,
                sourceId: r.sourceId,
                reason: a instanceof Error ? a.message : "fragment-preparation-failed"
            });
        }
        y.onmessage = null, y.close();
    }
};

export{ G as rawFragmentTransfers };
`;
