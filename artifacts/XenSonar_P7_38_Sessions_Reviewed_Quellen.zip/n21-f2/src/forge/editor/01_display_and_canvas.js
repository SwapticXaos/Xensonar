function __forgeRestoreViewport(view={}){const valid=Number.isFinite(view.spanX)&&view.spanX>0&&view.spanX<=1;return {...view,autoFitX:valid?view.spanX>=.999999:true,spanX:valid?view.spanX:1,startX:valid?Math.max(0,Math.min(1-view.spanX,view.startX||0)):0}}

// Display-only, data-resolution raster cache. Audio/Carrier fields are never resampled in place.
let __forgeDisplayRasterCache = new WeakMap();
// Forget only cached pixels/canvases, not the underlying carrier drawing.
function __f449ReleaseForgeDisplayCache(){
 __forgeDisplayRasterCache=new WeakMap();
 __forgeDonorDisplayCache=new WeakMap();
}
function __forgeDisplayCanvas(width,height){
  const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;return canvas;
}
function __forgeDisplayLayers(args){
  const data=args.spectralData,width=data.width,height=data.height;
  const keys=[data,args.renderVersion,args.colorLut,args.showGrain,args.variant,args.forge3Lens,args.forge3Field,args.activeVisibilityMask,args.traceVisibilityMask,args.showTraceLayer,width,height];
  let layer=__forgeDisplayRasterCache.get(args.canvas);
  const stable=Number.isFinite(args.renderVersion)&&layer&&keys.every((key,i)=>Object.is(key,layer.keys[i]));
  if(!stable){
    const raster=layer?.raster??__forgeDisplayCanvas(width,height);
    if(raster.width!==width)raster.width=width;if(raster.height!==height)raster.height=height;
    __F33NativeFrame({...args,canvas:raster,viewPort:{offsetX:0,offsetY:0,zoomX:1,zoomY:1}});
    layer={keys,raster,protection:null,columnMask:null};__forgeDisplayRasterCache.set(args.canvas,layer);
  }
  return layer;
}
function __forgeDisplayDraw(ctx,raster,args){
  const {offsetX,offsetY,zoomX,zoomY}=args.viewPort;
  if(!(zoomX>0&&zoomY>0))return;
  const unit=zoomX===1&&zoomY===1&&Number.isInteger(offsetX)&&Number.isInteger(offsetY);
  ctx.save();ctx.imageSmoothingEnabled=!unit;
  ctx.drawImage(raster,offsetX,offsetY,args.canvas.width/zoomX,args.canvas.height/zoomY,0,0,args.canvas.width,args.canvas.height);ctx.restore();
}
function __F33BaseFrame(args){
  const ctx=args.canvas.getContext('2d');if(!ctx)return;
  const layer=__forgeDisplayLayers(args),lut=args.colorLut;
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=1;
  ctx.fillStyle=`rgb(${lut[0]},${lut[1]},${lut[2]})`;ctx.fillRect(0,0,args.canvas.width,args.canvas.height);
  ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';__forgeDisplayDraw(ctx,layer.raster,args);ctx.restore();
}
// Protect the original energy/grain/lens image, including faint tool texture.
function __forgeDisplayCarrierLayers(args){
  const layer=__forgeDisplayLayers(args);if(layer.protection&&layer.columnMask)return layer;
  const data=args.spectralData,width=data.width,height=data.height;
  const protection=__forgeDisplayCanvas(width,height),ctx=protection.getContext('2d');
  const image=ctx.createImageData(width,height),pixels=image.data,active=new Uint8Array(width);
  // A non-zero cell does not necessarily have a visible colour.  In F3.21
  // all non-zero cells were 100% protected, so the dark fringe of soft paint
  // punched black holes through the donor spectrogram.  Protect the actual
  // DISPLAYED carrier contrast instead of treating float nonzero as opacity.
  // This mask is visual only: neither PCM nor spectral/grain/trace data change.
  const displayed=layer.raster.getContext('2d').getImageData(0,0,width,height).data;
  const bgR=args.colorLut[0],bgG=args.colorLut[1],bgB=args.colorLut[2];
  const smoothstep=(v)=>{const t=Math.max(0,Math.min(1,v));return t*t*(3-2*t);};
  const traces=args.variant==='forge3'&&args.forge3Lens!=='hear'&&args.showTraceLayer?args.traceVisibilityMask:null;
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
    const at=y*width+x,raw=data.data[at],painted=Number.isFinite(raw)&&raw>0;
    if(painted)active[x]=1; // Preserve the original time-column support.
    if(!painted&&!((traces?.[at]??0)>.02))continue;
    const pos=at*4;
    const contrast=Math.max(
      Math.abs(displayed[pos]-bgR),
      Math.abs(displayed[pos+1]-bgG),
      Math.abs(displayed[pos+2]-bgB));
    // Up to eight RGB levels above background: transparent to the donor.
    // At 40 levels or more: preserve the original carrier pixel exactly.
    const protectionAlpha=Math.round(255*smoothstep((contrast-8)/32));
    if(!protectionAlpha)continue;
    pixels[pos]=255;pixels[pos+1]=255;pixels[pos+2]=255;pixels[pos+3]=protectionAlpha;
  }
  ctx.putImageData(image,0,0);
  const columnMask=__forgeDisplayCanvas(width,1),mc=columnMask.getContext('2d'),mi=mc.createImageData(width,1);
  for(let x=0;x<width;x++){mi.data[x*4]=255;mi.data[x*4+1]=255;mi.data[x*4+2]=255;mi.data[x*4+3]=active[x]?255:0;}mc.putImageData(mi,0,0);
  layer.protection=protection;layer.columnMask=columnMask;return layer;
}
let __forgeDonorDisplayCache=new WeakMap();
function __forgeDisplayDonor(args,record,enabled){
  // A hidden or not-yet-prepared donor leaves the full original image untouched.
  if(!enabled||!record?.canvas||!record.mantle)return;
  const ctx=args.canvas.getContext('2d');if(!ctx)return;
  const {offsetX,offsetY,zoomX,zoomY}=args.viewPort;
  if(!(zoomX>0&&zoomY>0))return;
  const layer=__forgeDisplayCarrierLayers(args),width=args.canvas.width,height=args.canvas.height;
  let scratch=__forgeDonorDisplayCache.get(args.canvas);
  if(!scratch){scratch=__forgeDisplayCanvas(width,height);__forgeDonorDisplayCache.set(args.canvas,scratch);}
  if(scratch.width!==width)scratch.width=width;if(scratch.height!==height)scratch.height=height;
  const sc=scratch.getContext('2d');sc.save();sc.setTransform(1,0,0,1,0,0);
  sc.globalCompositeOperation='source-over';sc.globalAlpha=1;sc.clearRect(0,0,width,height);
  sc.imageSmoothingEnabled=true;sc.imageSmoothingQuality='high';
  const scaleX=record.canvas.width/args.spectralData.width,scaleY=record.canvas.height/args.spectralData.height;
  sc.drawImage(record.canvas,offsetX*scaleX,offsetY*scaleY,width/zoomX*scaleX,height/zoomY*scaleY,0,0,width,height);
  sc.globalCompositeOperation='destination-in';
  sc.drawImage(layer.columnMask,offsetX,0,width/zoomX,1,0,0,width,height);
  sc.globalCompositeOperation='destination-out';__forgeDisplayDraw(sc,layer.protection,args);sc.restore();
  ctx.save();ctx.setTransform(1,0,0,1,0,0);ctx.globalCompositeOperation='source-over';ctx.globalAlpha=.68;
  ctx.drawImage(scratch,0,0);ctx.restore();
}

function __forgeDisplayVisibility(data,field){
  const count=data.width*data.height,active=new Float32Array(count),trace=new Float32Array(count);
  const energy=data.data,weights=field?.sourceWeight??[],bias=field?.traceBias??[],mass=field?.bodyMass??[];
  for(let i=0;i<count;i++){
    const amp=energy[i]??0;if(amp>.003){active[i]=amp;continue;}
    const value=Math.max(bias[i]??0,(weights[i]??0)*.24,(mass[i]??0)*.12);
    if(value>.02)trace[i]=Math.min(1,value);
  }
  return{active,trace};
}

// Display controls share the existing persisted palette/grain settings.
function __ForgeVisualKey({colorMapName,showGrain,onGrain}){
  const gradient=P.useMemo(()=>{
    const lut=bE(xO[colorMapName]??xO.magma),stops=[];
    for(let i=0;i<=8;i++){const at=Math.round(i/8*255)*3;stops.push(`rgb(${lut[at]},${lut[at+1]},${lut[at+2]}) ${i/8*100}%`);}
    return `linear-gradient(90deg,${stops.join(',')})`;
  },[colorMapName]);
  return u.jsxs('div',{'data-forge-visual-key':'true',style:{margin:'7px 0',fontSize:10,lineHeight:1.5,color:'#aeb9c9'},children:[
    u.jsx('div',{style:{height:5,borderRadius:3,background:gradient,marginBottom:3},'aria-hidden':true}),
    u.jsx('div',{children:'Figur: Energie · schwach → stark'}),
    u.jsxs('label',{style:{display:'flex',alignItems:'center',gap:5,marginTop:5,cursor:'pointer'},title:"Shows saved granularity as a color. Its audible effect depends on the selected listening mode.",children:[
      u.jsx('input',{type:'checkbox',checked:showGrain,onChange:event=>onGrain(event.currentTarget.checked),'aria-label':"Show Grain Colors",style:{accentColor:'#63c8d2'}}),
      u.jsx('span',{children:"Grain Colors (G)"}),
    ]}),
    showGrain&&u.jsx('div',{style:{color:'#91a5ba'},children:"Red: short · Turquoise: long"}),
    u.jsx('div',{style:{marginTop:3,color:'#91a5ba'},children:"Body / Source: parameters of the selected lens"}),
  ]});
}

// F3.56.10: display-only bridge for the F3.52+ / F3.56 Sound Material pipeline.
// Uses its already computed PCM spectrogram, not a second FFT and never changes synthesis.
function D5e(args){const display=args.variant==='forge3'&&!__f333WorkingSource(pe.getState())?{...args,forge3Lens:'hear',showTraceLayer:false}:args;__F33BaseFrame(display);}function N5e({canvas:e,viewPort:t,spectralData:n,activeTool:r,lineStart:a,toolSettings:o,stampPhase:i,stampSelStart:s,stampSelEnd:l,stampData:c,stampScaleX:d,stampScaleY:p,stampRotation:f,stampFlipX:b,stampFlipY:g,mousePos:y,guideDragMarkerIndex:x,guideLayout:A,colorLut:M,showGrainLayer:v,synthMode:w,showPlayheadMarker:R,isPlaying:k,playheadPosition:I,showCarrierDonorV2Overlay:E,showCarrierDonorV2ContinuityOverlay:F,showCarrierDonorV2BindingOverlay:L,carrierDonorV2Skeleton:B,carrierDonorV2ContinuityGraph:O,carrierAnchorMap:T,carrierBindingMap:_,v2OverlayWarning:G,screenToDataFromScreen:j}){if(!e)return;const N=e.getContext("2d");if(!N)return;const W=e.width,V=e.height;N.clearRect(0,0,W,V);const{offsetX:U,zoomX:H,offsetY:q,zoomY:K}=t,Y=[55,110,220,440,880,1760,3520,7040,14080,65.41,130.81,261.63,523.25,1046.5,2093,4186,8372];N.strokeStyle="rgba(255,255,255,0.07)",N.lineWidth=1;for(const X of Y){const ne=(WU(X,n.height)-q)*K;ne<0||ne>V||(N.beginPath(),N.moveTo(0,ne),N.lineTo(W,ne),N.stroke())}const{safeBars:J,barWidthData:Z,guideMarkers:te}=A;N.strokeStyle="rgba(103, 232, 249, 0.14)",N.lineWidth=1;for(let X=0;X<J;X++){const Q=X*Z;for(let ne=0;ne<te.length;ne++){const ie=(Q+te[ne]*Z-U)*H;if(ie<0||ie>W)continue;N.beginPath(),N.moveTo(ie,0),N.lineTo(ie,V),N.stroke();const de=x===ne,oe=3,ue=4;N.fillStyle=de?"rgba(34, 211, 238, 0.95)":"rgba(125, 211, 252, 0.82)",N.beginPath(),N.moveTo(ie,oe+7),N.lineTo(ie-ue,oe),N.lineTo(ie+ue,oe),N.closePath(),N.fill()}}N.strokeStyle="rgba(34, 211, 238, 0.30)",N.lineWidth=1.3;for(let X=0;X<=J;X++){const ne=(X*Z-U)*H;ne<0||ne>W||(N.beginPath(),N.moveTo(ne,0),N.lineTo(ne,V),N.stroke())}if(N.lineWidth=1,E&&B){if(F&&O&&T.size>0){N.save(),N.lineCap="round";for(const X of O.links){const Q=T.get(X.fromAnchorId),ne=T.get(X.toAnchorId);if(!Q||!ne)continue;const ee=(Q.timeIndex-U)*H,ie=(Q.centerBin-q)*K,de=(ne.timeIndex-U)*H,oe=(ne.centerBin-q)*K;ee<-14&&de<-14||ee>W+14&&de>W+14||ie<-14&&oe<-14||ie>V+14&&oe>V+14||(N.strokeStyle=L5e(X),N.lineWidth=.8+X.continuityScore*1.5,N.beginPath(),N.moveTo(ee,ie),N.lineTo(de,oe),N.stroke())}N.restore()}for(const X of B.anchorsByTime)for(const Q of X){const ne=(Q.timeIndex-U)*H,ee=(Q.centerBin-q)*K;if(ne<-10||ne>W+10||ee<-10||ee>V+10)continue;const ie=Math.max(2,Math.min(6,1.6+Q.energy*6)),de=Math.max(1,Q.bandwidthBins*K/2),oe=T5e(Q);if(N.strokeStyle=oe,N.lineWidth=Q.regime==="tonal"?1.4:1,N.beginPath(),N.moveTo(ne,ee-de),N.lineTo(ne,ee+de),N.stroke(),N.fillStyle=oe,N.beginPath(),N.arc(ne,ee,ie,0,Math.PI*2),N.fill(),L){const ue=_.get(Q.id),fe=B5e(ue);ue&&fe&&(N.strokeStyle=fe,N.lineWidth=1+ue.confidence*2.2,N.beginPath(),N.arc(ne,ee,ie+2.6,0,Math.PI*2),N.stroke())}}N.lineWidth=1}if(G){N.save(),N.font="11px sans-serif";const X=8,ne=N.measureText(G).width+X*2,ee=24,ie=Math.max(8,W-ne-8),de=8;N.fillStyle="rgba(245, 158, 11, 0.14)",N.strokeStyle="rgba(245, 158, 11, 0.45)",N.lineWidth=1,N.fillRect(ie,de,ne,ee),N.strokeRect(ie+.5,de+.5,ne-1,ee-1),N.fillStyle="rgba(253, 224, 71, 0.95)",N.fillText(G,ie+X,de+15),N.restore()}if(k||R){const X=(I*n.width-U)*H,Q=Math.max(24,H*10),ne=X-Q*.5,ee=X+Q*.5;if(ee>=0&&ne<=W){const ie=Math.max(0,ne),de=Math.min(W,ee),oe=N.createLinearGradient(ie,0,de,0);oe.addColorStop(0,"rgba(0, 255, 136, 0.00)"),oe.addColorStop(.12,"rgba(0, 255, 136, 0.18)"),oe.addColorStop(.5,"rgba(90, 255, 180, 0.40)"),oe.addColorStop(.88,"rgba(0, 255, 136, 0.18)"),oe.addColorStop(1,"rgba(0, 255, 136, 0.00)"),N.fillStyle=oe,N.fillRect(ie,0,Math.max(0,de-ie),V),N.strokeStyle="rgba(0,255,136,0.34)",N.lineWidth=1.2,N.strokeRect(ie+.5,.5,Math.max(0,de-ie-1),V-1)}if(X>=0&&X<=W)N.save(),N.strokeStyle="#00ff88",N.lineWidth=3.5,N.shadowColor="#00ff88",N.shadowBlur=22,N.beginPath(),N.moveTo(X,0),N.lineTo(X,V),N.stroke(),N.restore(),N.fillStyle="#7dffbf",N.beginPath(),N.moveTo(X-6,0),N.lineTo(X+6,0),N.lineTo(X,10),N.closePath(),N.fill();else{const ie=X<0?0:W,de=X<0?1:-1;N.fillStyle="rgba(0,255,136,0.9)",N.beginPath(),N.moveTo(ie,18),N.lineTo(ie+de*10,12),N.lineTo(ie+de*10,24),N.closePath(),N.fill()}}if(r==="line"&&a){const X=(a.x-U)*H,Q=(a.y-q)*K;N.fillStyle="#ff0",N.beginPath(),N.arc(X,Q,4,0,Math.PI*2),N.fill()}if(r==="stamp"&&i==="selecting"&&s&&l){const X=(Math.min(s.x,l.x)-U)*H,Q=(Math.min(s.y,l.y)-q)*K,ne=Math.abs(l.x-s.x)*H,ee=Math.abs(l.y-s.y)*K;N.strokeStyle="#ff0",N.lineWidth=1,N.setLineDash([4,4]),N.strokeRect(X,Q,ne,ee),N.setLineDash([]),N.fillStyle="rgba(255, 255, 0, 0.05)",N.fillRect(X,Q,ne,ee)}if(r==="stamp"&&i==="stamping"&&c&&y){const X=j(y.sx,y.sy),Q=n.getStampBounds(c,{scaleX:d,scaleY:p,rotation:f,flipX:b,flipY:g}),{halfW:ne,halfH:ee,outW:ie,outH:de}=Q,oe=(X.x-ne-U)*H,ue=(X.y-ee-q)*K,fe=ie*H,he=de*K;N.strokeStyle="#0ff",N.lineWidth=1,N.setLineDash([3,3]),N.strokeRect(oe,ue,fe,he),N.setLineDash([]),N.fillStyle="rgba(0, 255, 255, 0.08)",N.fillRect(oe,ue,fe,he);const re={scaleX:d,scaleY:p,rotation:f,flipX:b,flipY:g};if(fe>1&&he>1&&ie>1&&de>1){const le=document.createElement("canvas");le.width=ie,le.height=de;const Ae=le.getContext("2d");if(Ae){const ce=Ae.createImageData(ie,de),ge=ce.data;for(let Ce=0;Ce<de;Ce++)for(let Re=0;Re<ie;Re++){const xe=n.sampleStampTransformed(c,Re-ne,Ce-ee,re).amp;if(xe<=.01)continue;const Be=Math.round(xe*255)*3,Ie=(Ce*ie+Re)*4;ge[Ie]=M[Be],ge[Ie+1]=M[Be+1],ge[Ie+2]=M[Be+2],ge[Ie+3]=115}Ae.putImageData(ce,0,0),N.save(),N.imageSmoothingEnabled=!0,N.imageSmoothingQuality="high",N.drawImage(le,oe,ue,fe,he),N.restore()}}}if(y){const{sx:X,sy:Q}=y,ne=o.eraseMode,ee=o.brushSize,ie=ee*H,de=ee*K;N.save(),N.strokeStyle=ne?"rgba(255, 80, 80, 0.7)":"rgba(255, 255, 255, 0.6)",N.lineWidth=1,(r!=="stamp"||i!=="selecting")&&(N.beginPath(),N.ellipse(X,Q,Math.max(1,ie),Math.max(1,de),0,0,Math.PI*2),N.stroke());const oe=Math.max(ie,de)+6,ue=14;if(N.strokeStyle=ne?"rgba(255, 100, 100, 0.9)":"rgba(255, 255, 255, 0.8)",N.lineWidth=1,N.beginPath(),N.moveTo(X,Q-oe-ue),N.lineTo(X,Q-oe),N.stroke(),N.beginPath(),N.moveTo(X,Q+oe),N.lineTo(X,Q+oe+ue),N.stroke(),N.beginPath(),N.moveTo(X-oe-ue,Q),N.lineTo(X-oe,Q),N.stroke(),N.beginPath(),N.moveTo(X+oe,Q),N.lineTo(X+oe+ue,Q),N.stroke(),N.fillStyle=ne?"#ff4444":"#ffffff",N.beginPath(),N.arc(X,Q,1.5,0,Math.PI*2),N.fill(),ne&&(N.strokeStyle="rgba(255, 80, 80, 0.9)",N.lineWidth=2,N.beginPath(),N.moveTo(X-4,Q),N.lineTo(X+4,Q),N.stroke()),w==="granular"||v){const[fe,he,re]=kB(o.grainSize);N.fillStyle=`rgb(${fe}, ${he}, ${re})`,N.beginPath(),N.arc(X+oe+4,Q+oe+4,3,0,Math.PI*2),N.fill(),N.strokeStyle="rgba(255,255,255,0.5)",N.lineWidth=.5,N.stroke()}N.restore()}}function O5e({hoverInfo:e,forge3Hover:t,eraseMode:n}){return e?u.jsxs("div",{className:"absolute bottom-1 right-1 bg-black/70 text-xs text-gray-300 px-2 py-1 rounded font-mono pointer-events-none",children:[e.note," (",e.freq," Hz) | ",e.time.toFixed(3),"s",t&&u.jsx("span",{className:"ml-2 text-emerald-300",children:t}),n&&u.jsx("span",{className:"ml-2 text-red-400",children:"⊖ RADIEREN"})]}):null}function _5e({isPlaying:e,playheadPosition:t,variant:n,forge3Lens:r}){return u.jsxs(u.Fragment,{children:[e&&u.jsxs("div",{className:"absolute top-2 right-3 bg-black/65 text-[10px] text-emerald-300 px-2 py-1 rounded pointer-events-none font-mono",children:["Scan ",Math.max(0,Math.min(100,t*100)).toFixed(1),"%"]}),n==="forge3"&&u.jsxs("div",{className:"absolute top-2 right-3 translate-y-6 bg-black/65 text-[10px] text-cyan-200 px-2 py-1 rounded pointer-events-none font-mono",children:["Lens:",r==="body"?"Body":r==="source"?"Source":"Listen"]})]})}function z5e({activeTool:e,stampPhase:t,stampScaleX:n,stampScaleY:r}){return e!=="stamp"?null:u.jsxs("div",{className:"absolute top-2 left-14 bg-black/80 text-xs text-cyan-300 px-3 py-1.5 rounded pointer-events-none",children:[t==="idle"&&"📋 Drag a rectangle around the desired area",t==="selecting"&&"📋 Select area... (release to confirm)",t==="stamping"&&`📋 Click = Stamp | Scroll = Uniform Scale | Arrow Keys = Stretch | X: ${(n*100).toFixed(0)}% Y: ${(r*100).toFixed(0)}%`]})}function j5e({spectralHeight:e,viewPort:t,canvasHeight:n}){const tune=P.useSyncExternalStore(__F3564Master.subscribe,__F3564Master.getSnapshot,__F3564Master.getSnapshot);const pitchRatio=2**(tune.tuning/12);return u.jsxs("div",{className:"absolute left-0 top-0 bottom-0 w-12 pointer-events-none flex flex-col justify-between py-1",children:[[2e4,1e4,5e3,2e3,1e3,500,200,100,50,20].map(r=>{const o=(WU(r/pitchRatio,e)-t.offsetY)*t.zoomY;return!n||o<0||o>n?null:u.jsx("div",{className:"absolute text-[9px] text-gray-500 font-mono",style:{top:Math.min(Math.max(0,n-12),Math.max(0,o)),left:2},children:r>=1e3?`${r/1e3}k`:r},r)}),t.autoFitY?null:u.jsxs("div",{className:"absolute left-1 bottom-1 max-w-11 leading-[9px] text-[8px] text-gray-500 font-mono",children:["Tuned Hz",u.jsx("br",{}),"A/B/C root-rel."]})]})}/* Navigator one-shot selection lives outside the undoable musical project.
   Selection is a draft, never a second playback or sample library owner. */
const __ForgeNavigatorSample=(()=>{
 const listeners=new Set();let state=Object.freeze({selection:null,busy:false,message:''});
 const snapshot=()=>state,subscribe=fn=>(listeners.add(fn),()=>listeners.delete(fn));
 function update(patch){state=Object.freeze({...state,...patch});for(const fn of listeners)fn()}
 function select(a,b){__f333StopNavigatorPreview();const source=pe.getState(),start=Math.max(0,Math.min(1,Math.min(a,b))),end=Math.max(0,Math.min(1,Math.max(a,b)));
  if(!Number.isFinite(start)||!Number.isFinite(end)||end-start<.003)return clear();
  update({selection:{start,end,source:source.sourceAsset,revision:source.renderVersion,route:__f333Route(source)},barsDraft:null,message:''});
 }
 function clear(){__f333StopNavigatorPreview();if(state.selection||state.message)update({selection:null,message:''})}
 function current(){const s=state.selection,p=pe.getState();return !!s&&s.revision===p.renderVersion&&s.source===p.sourceAsset&&s.route===__f333Route(p)?s:null}
 return {snapshot,subscribe,select,clear,current,update};
})();
/* Navigator selection metadata belongs to the selection draft, never to the Carrier.
   An untouched suggestion is marked uncertain; users can override it explicitly. */
function __f333NavigatorEstimateBars(selection,sourceBars){
 if(!selection)return null;
 const source=Math.max(1,Math.min(16,Math.round(Number(sourceBars)||1)));
 return Math.max(1,Math.min(16,Math.round((selection.end-selection.start)*source)));
}
function __f333NavigatorBars(sourceBars){
 const selected=__ForgeNavigatorSample.current();if(!selected)return null;
 const draft=__ForgeNavigatorSample.snapshot().barsDraft;
 return Number.isInteger(draft)&&draft>=1&&draft<=16?draft:__f333NavigatorEstimateBars(selected,sourceBars);
}
/* P7.3: purple sample-region handles are NOT the cyan Navigator viewport handles.
   Hit-testing is read-only and does not allocate any audio object. */
function __f333NavigatorSampleEdgeHit(x,width,selected,zone=9){
 if(!selected||!Number.isFinite(x)||!Number.isFinite(width)||width<=0||typeof zone!=='number'||!Number.isFinite(zone)||zone<=0)return null;
 const left=selected.start*width,right=selected.end*width;
 const dl=Math.abs(x-left),dr=Math.abs(x-right);
 return dl<=zone||dr<=zone?(dl<=dr?'selection-left':'selection-right'):null;
}
function __f333NavigatorSampleResize(edge,opposite,pointer){
 const minWidth=.003;
 const fixed=Math.max(0,Math.min(1,Number.isFinite(opposite)?opposite:0));
 const p=Math.max(0,Math.min(1,Number.isFinite(pointer)?pointer:fixed));
 return edge==='selection-left'?{start:Math.max(0,Math.min(fixed-minWidth,p)),end:fixed}:
  {start:fixed,end:Math.min(1,Math.max(fixed+minWidth,p))};
}
/* P7.5: the SAME Navigator sample edges in the magnified Forge painting area.
   No secondary selection state, no filled area and no audio/RAF work. */
function __f375ForgeSelectionMainPixel(fraction,geometry){
 if(!geometry||!Number.isFinite(fraction)||!Number.isFinite(geometry.width)||geometry.width<=0||
    !Number.isFinite(geometry.zoomX)||geometry.zoomX<=0||!Number.isFinite(geometry.offsetX)||
    !Number.isFinite(geometry.rectWidth)||geometry.rectWidth<=0)return null;
 const canvasWidth=Number.isFinite(geometry.canvasWidth)&&geometry.canvasWidth>0?geometry.canvasWidth:geometry.rectWidth;
 const pixel=(fraction*geometry.width-geometry.offsetX)*geometry.zoomX*geometry.rectWidth/canvasWidth;
 return pixel>=0&&pixel<=geometry.rectWidth?pixel:null;
}
function __f375ForgeMainSelectionHandles({mainCanvasRef,spectralWidth,viewPort}){
 const snapshot=P.useSyncExternalStore(__ForgeNavigatorSample.subscribe,__ForgeNavigatorSample.snapshot,__ForgeNavigatorSample.snapshot);
 const selected=__ForgeNavigatorSample.current(),dragCleanup=P.useRef(null);
 P.useEffect(()=>()=>{dragCleanup.current?.();dragCleanup.current=null},[]);
 if(!selected||!Number.isFinite(spectralWidth)||spectralWidth<=0)return null;
 const canvas=mainCanvasRef.current,rect=canvas?.getBoundingClientRect?.();
 if(!canvas||!rect||rect.width<=0)return null;
 const geom={width:spectralWidth,zoomX:viewPort.zoomX,offsetX:viewPort.offsetX,rectWidth:rect.width,canvasWidth:canvas.width};
 const start=__f375ForgeSelectionMainPixel(selected.start,geom),end=__f375ForgeSelectionMainPixel(selected.end,geom);
 const makeHandle=(edge,position)=>{
  if(position===null)return null;
  const beginDrag=event=>{
   if(event.button!==0)return;
   event.preventDefault();event.stopPropagation();
   dragCleanup.current?.();
   const initial=__ForgeNavigatorSample.current();if(!initial)return;
   const fixed=edge==='selection-left'?initial.end:initial.start;
   const onMove=pointer=>{
    const c=mainCanvasRef.current,box=c?.getBoundingClientRect?.();if(!c||!box||box.width<=0)return;
    const x=Math.max(0,Math.min(box.width,pointer.clientX-box.left));
    const dataX=viewPort.offsetX+x*c.width/box.width/Math.max(.00001,viewPort.zoomX);
    const fraction=Math.max(0,Math.min(1,dataX/spectralWidth));
    const span=__f333NavigatorSampleResize(edge,fixed,fraction);
    __ForgeNavigatorSample.select(span.start,span.end);
   };
   const done=()=>{dragCleanup.current?.();dragCleanup.current=null};
   const onBlur=()=>done();
   const cleanup=()=>{window.removeEventListener('mousemove',onMove);window.removeEventListener('mouseup',done);window.removeEventListener('blur',onBlur)};
   dragCleanup.current=cleanup;
   window.addEventListener('mousemove',onMove);window.addEventListener('mouseup',done);window.addEventListener('blur',onBlur);
  };
  return u.jsxs('div',{
   ...(edge==='selection-left'?{'data-forge-main-sample-start':true}:{'data-forge-main-sample-end':true}),
   'aria-label':edge==='selection-left'?'Trim sample start':'Trim sample end',
   title:edge==='selection-left'?'Drag violet triangle to trim sample start':'Drag violet triangle to trim sample end',
   style:{position:'absolute',top:0,bottom:0,left:position+'px',width:'14px',transform:'translateX(-50%)',cursor:'ew-resize',zIndex:30,touchAction:'none'},onMouseDown:beginDrag,
   children:[
    u.jsx('span',{style:{pointerEvents:'none',position:'absolute',left:'50%',top:0,bottom:0,width:'1px',transform:'translateX(-50%)',background:'rgba(192,132,252,.9)'}}),
    u.jsx('span',{style:{pointerEvents:'none',position:'absolute',left:'50%',top:0,transform:'translateX(-50%)',width:0,height:0,borderLeft:'5px solid transparent',borderRight:'5px solid transparent',borderTop:'8px solid #d8a0f5'}})
   ]
  });
 };
 return u.jsxs(P.Fragment,{children:[makeHandle('selection-left',start),makeHandle('selection-right',end)]});
}
function G5e({overviewWrapRef:e,overviewCanvasRef:t,viewPort:n,onNavigatorMouseDown:r}){
 const state=P.useSyncExternalStore(__ForgeNavigatorSample.subscribe,__ForgeNavigatorSample.snapshot,__ForgeNavigatorSample.snapshot);
 const selected=__ForgeNavigatorSample.current();
 return u.jsxs("div",{className:"z-10 border-t border-gray-800 bg-gray-950 px-3 py-2 shadow-[0_-10px_24px_rgba(0,0,0,0.45)]",children:[u.jsxs("div",{className:"flex items-center gap-3 text-[10px] text-gray-500 mb-1.5",children:[u.jsx("span",{className:"text-cyan-300 font-semibold",children:"Navigator"}),u.jsx("button",{type:"button",onClick:()=>pe.getState().setViewPort({autoFitX:true,spanX:1,startX:0,offsetX:0}),className:"rounded border border-cyan-900 px-2 py-0.5 text-cyan-200","data-forge-fit-drawing":true,children:"Whole Drawing"}),u.jsx("span",{children:"Click = playback position · Drag = select sample · Alt+Drag = move"}),u.jsx("span",{title:"Violet selection edges trim the sample, also via the matching triangles and lines above the magnified painting. Cyan viewport edges zoom the drawing.",children:"Violet trim · Cyan zoom"}),selected&&u.jsx("button",{type:"button",onClick:__ForgeNavigatorSample.clear,className:"rounded border border-violet-800 px-1 text-violet-200",title:"Clear sample selection",children:"✕"}),u.jsxs("span",{className:"ml-auto font-mono text-gray-400",children:["X ",n.zoomX.toFixed(1),"x"]})]}),u.jsxs("div",{ref:e,className:"relative h-14 min-w-0 rounded-md overflow-hidden border border-gray-800 bg-black cursor-crosshair","data-forge-navigator":"full-drawing",style:{width:"100%"},onMouseDown:r,onMouseMove:event=>{
 const box=event.currentTarget.getBoundingClientRect(),geometry=t.current?.__navigatorViewport;
 const pointer=Math.max(0,Math.min(box.width,event.clientX-box.left));
 const sampleEdge=!event.altKey?__f333NavigatorSampleEdgeHit(pointer,box.width,__ForgeNavigatorSample.current()):null;
 const mode=geometry?Z5e(pointer,geometry):'move';
 event.currentTarget.style.cursor=sampleEdge?'ew-resize':mode==='move'?(event.altKey?'grab':'crosshair'):'ew-resize';
 },children:[u.jsx("canvas",{ref:t,className:"block w-full h-full",style:{imageRendering:"pixelated",width:"100%",height:"100%"}}),selected&&u.jsx("div",{"data-forge-navigator-sample-selection":true,"aria-label":"One-shot sample selection",className:"pointer-events-none absolute inset-y-0 rounded border-x-2 border-violet-200 bg-violet-400/30",style:{left:selected.start*100+"%",width:(selected.end-selected.start)*100+"%",background:"rgba(167,139,250,0.32)",borderLeft:"2px solid rgba(221,214,254,0.96)",borderRight:"2px solid rgba(221,214,254,0.96)"},children:state.previewing&&Number.isFinite(state.previewDurationSec)&&state.previewDurationSec>0?u.jsx("span",{"data-forge-navigator-region-playhead":true,"aria-hidden":true,className:"forge-navigator-region-sweep",style:{"--forge-region-preview-duration":state.previewDurationSec+"s"},children:u.jsx("span",{className:"forge-navigator-region-playhead"})}):null})]})]})}const H5e=.2,V5e=5,YO=72,JO=180,W5e=.0011,U5e=10;function ZO(e){return Number.isFinite(e)?Math.max(H5e,Math.min(V5e,e)):1}function X5e(e){const t=e.deltaMode===1?e.deltaY*16:e.deltaMode===2?e.deltaY*160:e.deltaY;return Number.isFinite(t)?Math.max(-YO,Math.min(YO,t)):0}function e_(e){const t=Math.max(1,e.spectralWidth),n=Math.max(1,Math.min(t,e.mainCanvasWidth/e.zoomX)),r=e.offsetX/t*e.containerWidth,a=Math.max(e.minWidthPx??10,n/t*e.containerWidth);return{visibleWidth:n,leftPx:r,widthPx:a,rightPx:r+a}}function Y5e(e,t,n){return Math.max(0,Math.min(e-t,n))}function J5e(e){const t=Math.max(1,Math.min(e.spectralWidth,e.mainCanvasWidth/e.zoomX)),n=Math.max(16,e.spectralWidth*.015),r=e.offsetX,a=r+t,o=e.pointerX/e.containerWidth*e.spectralWidth;if(e.mode==="resize-left"){const l=Math.max(0,Math.min(o,a-n)),c=Math.max(n,a-l),d=Math.max(.1,Math.min(20,e.mainCanvasWidth/c));return{offsetX:l,zoomX:d}}if(e.mode==="resize-right"){const l=Math.max(r+n,Math.min(e.spectralWidth,o)),c=Math.max(n,l-r);return{zoomX:Math.max(.1,Math.min(20,e.mainCanvasWidth/c))}}const i=o-t*.5,s=Math.max(0,e.spectralWidth-t);return{offsetX:Math.max(0,Math.min(s,i))}}function Z5e(e,t,n=U5e){return Math.abs(e-t.leftPx)<=n?"resize-left":Math.abs(e-t.rightPx)<=n?"resize-right":"move"}function e4e({mainCanvasRef:e,colorLUTRef:t,spectralData:n,viewPort:r,setViewPort:a,renderVersion:o,showGrainLayer:i,synthMode:s,playheadPosition:l,isPlaying:c,showPlayheadMarker:d}){const p=P.useRef(null),f=P.useRef(null),b=P.useRef(null),g=P.useCallback(()=>{const A=f.current;if(!A)return;const M=A.getContext("2d");if(!M)return;const box=A.parentElement.getBoundingClientRect(),v=Math.max(1,Math.round(box.width)),w=Math.max(1,Math.round(box.height));if(A.width!==v)A.width=v;if(A.height!==w)A.height=w;M.clearRect(0,0,v,w);const R=t.current,k=i||s==="granular",I=n.width/v,E=n.height/w,cache=A.__fullOverview;let F;if(cache&&cache.grid===n&&cache.version===o&&cache.lut===R&&cache.grains===k&&cache.width===v&&cache.height===w)F=cache.pixels;else{F=M.createImageData(v,w);const L=F.data;for(let G=0;G<w;G++){const j=Math.floor(G*E),N=Math.min(n.height,Math.ceil((G+1)*E));for(let W=0;W<v;W++){const V=Math.floor(W*I),U=Math.min(n.width,Math.ceil((W+1)*I));let H=0,q=0;for(let J=j;J<N;J++)for(let Z=V;Z<U;Z++){const te=n.get(Z,J);te>H&&(H=te,q=n.getGrain(Z,J))}const K=Math.round(Math.max(0,Math.min(1,H))*255)*3,Y=(G*v+W)*4;if(k&&H>.01){const[J,Z,te]=kB(q),X=.36;L[Y]=Math.round(R[K]*(1-X)+J*X),L[Y+1]=Math.round(R[K+1]*(1-X)+Z*X),L[Y+2]=Math.round(R[K+2]*(1-X)+te*X)}else L[Y]=R[K],L[Y+1]=R[K+1],L[Y+2]=R[K+2];L[Y+3]=255}}A.__fullOverview={grid:n,version:o,lut:R,grains:k,width:v,height:w,pixels:F};}M.putImageData(F,0,0);const __liveViewport=pe.getState().viewPort,B=e_({spectralWidth:n.width,mainCanvasWidth:e.current?.width??n.width,containerWidth:v,offsetX:__liveViewport.offsetX,zoomX:__liveViewport.zoomX}),{widthPx:O}=B,T=Y5e(v,O,B.leftPx);A.__navigatorViewport=B;M.fillStyle="rgba(0, 0, 0, 0.28)",M.fillRect(0,0,T,w),M.fillRect(T+O,0,v-(T+O),w);const _=M.createLinearGradient(T,0,T+O,0);if(_.addColorStop(0,"rgba(34, 211, 238, 0.18)"),_.addColorStop(.5,"rgba(34, 211, 238, 0.08)"),_.addColorStop(1,"rgba(34, 211, 238, 0.18)"),M.fillStyle=_,M.fillRect(T,0,O,w),M.strokeStyle="rgba(103, 232, 249, 0.95)",M.lineWidth=2,M.strokeRect(T+.5,.5,Math.max(1,O-1),w-1),M.fillStyle="rgba(103, 232, 249, 0.95)",M.fillRect(T-1,2,4,w-4),M.fillRect(T+O-3,2,4,w-4),c||d){const G=l*v;M.strokeStyle="rgba(0,255,136,0.95)",M.lineWidth=1.5,M.beginPath(),M.moveTo(G,0),M.lineTo(G,w),M.stroke()}},[t,c,e,l,i,d,n,s,r,o]),y=P.useCallback((A,M)=>{const v=p.current,w=e.current;if(!v||!w)return;const R=v.getBoundingClientRect(),k=Math.max(0,Math.min(R.width,A-R.left));a(J5e({mode:M,pointerX:k,containerWidth:R.width,spectralWidth:n.width,mainCanvasWidth:w.width,offsetX:r.offsetX,zoomX:r.zoomX}))},[e,a,n.width,r.offsetX,r.zoomX]);P.useEffect(()=>{g()},[g,o]);/*navigator-bitmap-fit*/P.useEffect(()=>{const wrap=p.current,bitmap=f.current;if(!wrap||!bitmap||typeof ResizeObserver==="undefined")return;let frame=0;const sync=()=>{const box=wrap.getBoundingClientRect(),width=Math.max(1,Math.round(box.width)),height=Math.max(1,Math.round(box.height));if(!box.width||!box.height)return;if(bitmap.width!==width)bitmap.width=width;if(bitmap.height!==height)bitmap.height=height;g()};const queue=()=>{if(frame)cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{frame=0;sync()})};const observer=new ResizeObserver(queue);observer.observe(wrap);queue();return()=>{observer.disconnect();frame&&cancelAnimationFrame(frame)}},[g]);const x=P.useCallback(A=>{if(A.button!==0)return;const M=p.current,v=e.current;if(!M||!v)return;const w=M.getBoundingClientRect(),R=Math.max(0,Math.min(w.width,A.clientX-w.left)),k=e_({spectralWidth:n.width,mainCanvasWidth:v.width,containerWidth:w.width,offsetX:r.offsetX,zoomX:r.zoomX}),{leftPx:I}=k,E=Z5e(R,k),selection=__ForgeNavigatorSample.current(),selectionResize=!A.altKey?__f333NavigatorSampleEdgeHit(R,w.width,selection):null;
 b.current={mode:E,selectionResize,fixedRatio:selectionResize?(selectionResize==='selection-left'?selection.end:selection.start):0,select:!A.altKey&&!selectionResize&&E==='move',startRatio:w.width?R/w.width:0,grabOffsetPx:R-I,startLeftPx:I,startRightPx:k.rightPx,rectWidth:w.width,pointerDownX:A.clientX,moved:!1}},[e,n.width,r.offsetX,r.zoomX]);return P.useEffect(()=>{const ratio=v=>{const R=p.current?.getBoundingClientRect();return R&&R.width?Math.max(0,Math.min(1,(v-R.left)/R.width)):0};const A=v=>{const w=b.current;if(!w)return;if(!w.moved&&Math.abs(v.clientX-w.pointerDownX)>3)w.moved=!0;if(!w.moved)return;if(w.selectionResize){const span=__f333NavigatorSampleResize(w.selectionResize,w.fixedRatio,ratio(v.clientX));__ForgeNavigatorSample.select(span.start,span.end)}else if(w.select)__ForgeNavigatorSample.select(w.startRatio,ratio(v.clientX));else y(v.clientX,w.mode)},M=v=>{const w=b.current;if(!w)return;if(!w.moved){if(!w.selectionResize){__ForgeNavigatorSample.clear();__f340SeekFromNavigator(ratio(v.clientX))}}else if(w.selectionResize){const span=__f333NavigatorSampleResize(w.selectionResize,w.fixedRatio,ratio(v.clientX));__ForgeNavigatorSample.select(span.start,span.end)}else if(w.select)__ForgeNavigatorSample.select(w.startRatio,ratio(v.clientX));b.current=null};const cancel=()=>{b.current=null};return window.addEventListener("mousemove",A),window.addEventListener("mouseup",M),window.addEventListener("blur",cancel),()=>{window.removeEventListener("mousemove",A),window.removeEventListener("mouseup",M),window.removeEventListener("blur",cancel)}},[y]),{overviewWrapRef:p,overviewCanvasRef:f,onNavigatorMouseDown:x}}function t4e({mainCanvasRef:e,spectralWidth:t,viewPort:n,setViewPort:r,isPlaying:a,playheadPosition:o,renderVersion:i,renderMain:s,renderOverlay:l}){const __forgeVisible=P.useContext(__ForgeWorkspaceVisibility),c=P.useRef(null),d=P.useRef(()=>{});P.useEffect(()=>{if(!a)return;const p=e.current;if(!p)return;const f=Math.max(1,p.width/n.zoomX),b=Math.max(0,t-f),g=o*t,y=(g-n.offsetX)*n.zoomX,x=Math.max(36,p.width*.14);if(y<x||y>p.width-x){const A=g-f*.5,M=Math.max(0,Math.min(b,A));Math.abs(M-n.offsetX)>.5&&r({offsetX:M})}},[a,e,o,r,t,n.offsetX,n.zoomX]),P.useEffect(()=>{d.current=l},[l]),P.useEffect(()=>{if(!__forgeVisible)return;let p=!0;const f=()=>{p&&(d.current(),c.current=requestAnimationFrame(f))};return c.current=requestAnimationFrame(f),()=>{p=!1,c.current&&cancelAnimationFrame(c.current),c.current=null}},[__forgeVisible]),P.useEffect(()=>{if(__forgeVisible)s()},[s,i,__forgeVisible])}// Horizontal viewport must never expose time beyond the four-bar data domain.
// Preserve genuine zoom-in and clamp pan; only insufficient zoom is raised
// to the minimum that fills the newly measured canvas.
function __forgeResizeViewportProjection(view,previous,size,spectralWidth,spectralHeight){
 if(!size||size.width<=0||size.height<=0)return view;let next={...view};
 if(Number.isFinite(view.spanX)||view.autoFitX){const span=view.autoFitX?1:Math.max(.005,Math.min(1,view.spanX||1)),start=Math.max(0,Math.min(1-span,view.startX||0));next={...next,zoomX:size.width/(spectralWidth*span),offsetX:start*spectralWidth,spanX:span,startX:start,autoFitX:span>=.999999}}
 else if(previous?.width>0)next.zoomX=Math.max(.001,view.zoomX*size.width/previous.width);
 else next={...next,zoomX:size.width/spectralWidth,offsetX:0,spanX:1,startX:0,autoFitX:true};
 if(view.autoFitY)next={...next,zoomY:size.height/spectralHeight,offsetY:0};
 else if(previous?.height>0&&previous.height!==size.height)next.zoomY=Math.max(.001,view.zoomY*size.height/previous.height);
 else if(!previous?.height&&Math.abs((view.zoomY||1)-1)<.001&&Math.abs(view.offsetY||0)<.001)next.zoomY=size.height/spectralHeight;
 return __forgeClampHorizontalViewport(next,size.width,spectralWidth);
}
// Also guard viewport state restored *after* the ResizeObserver first fires.
function __forgeClampHorizontalViewport(view,canvasWidth,spectralWidth){
 const width=Math.max(1,canvasWidth),spectral=Math.max(1,spectralWidth),span=Number.isFinite(view.spanX)?Math.max(.005,Math.min(1,view.autoFitX?1:view.spanX)):null;
 const zoom=span?width/(spectral*span):Math.max(Number.isFinite(view.zoomX)&&view.zoomX>0?view.zoomX:1,width/spectral),offset=span?(view.startX||0)*spectral:view.offsetX||0;
 return {...view,zoomX:zoom,offsetX:Math.max(0,Math.min(offset,Math.max(0,spectral-width/zoom)))};
}
function n4e({containerRef,mainCanvasRef,overlayCanvasRef,spectralWidth,spectralHeight,setViewPort,renderMain,autoFitY=false,viewZoomY=1,viewPort}){
 const previous=P.useRef({width:0,height:0});
 const sync=P.useCallback(()=>{const area=containerRef.current,canvas=mainCanvasRef.current,overlay=overlayCanvasRef.current;if(!area||!canvas||!overlay)return;const box=area.getBoundingClientRect(),size={width:Math.floor(box.width),height:Math.floor(box.height)};if(size.width<1||size.height<1)return;
  const current=pe.getState().viewPort,next=__forgeResizeViewportProjection(current,previous.current,size,spectralWidth,spectralHeight);previous.current=size;
  for(const bitmap of [canvas,overlay]){if(bitmap.width!==size.width)bitmap.width=size.width;if(bitmap.height!==size.height)bitmap.height=size.height}
  if(['zoomX','zoomY','offsetX','offsetY','spanX','startX','autoFitX'].some(k=>typeof next[k]==='number'?Math.abs((current[k]??-1)-next[k])>.00001:next[k]!==current[k]))setViewPort(next);renderMain(next);
 },[containerRef,mainCanvasRef,overlayCanvasRef,spectralWidth,spectralHeight,setViewPort,renderMain]);
 P.useLayoutEffect(()=>{sync()},[sync,autoFitY,viewZoomY,viewPort?.spanX,viewPort?.startX,viewPort?.autoFitX]);
 P.useEffect(()=>{const area=containerRef.current;if(!area)return;const observer=new ResizeObserver(sync);observer.observe(area);return()=>observer.disconnect()},[containerRef,sync]);
}
// Clamp the gesture to the *visible* painting area before converting to spectral cells.
// For end coordinates the far edge is exclusive, allowing copyRegion(0,0,width,height).
function __f35616StampBoundary(clientX,clientY,canvas,toCell,width,height,farEdge){
 const rect=canvas?.getBoundingClientRect?.();
 if(!rect)return{x:0,y:0};
 const x=Math.max(rect.left,Math.min(rect.right,Number.isFinite(clientX)?clientX:rect.left));
 const y=Math.max(rect.top,Math.min(rect.bottom,Number.isFinite(clientY)?clientY:rect.top));
 const cell=toCell(x,y);
 const endX=farEdge?Math.max(0,width):Math.max(0,width-1);
 const endY=farEdge?Math.max(0,height):Math.max(0,height-1);
 return{x:Math.max(0,Math.min(endX,Math.floor(Number(cell.x)||0))),
         y:Math.max(0,Math.min(endY,Math.floor(Number(cell.y)||0)))};
}

function r4e({variant:e="legacy",forge3Lens:t="hear",showTraceLayer:n=!1}){P.useEffect(()=>{if(e!=="forge3")return;if(__forgeWorkspaceVisible)__F352Runtime.attach();return()=>__deactivateForgeWorkspace()},[e]);const r=P.useRef(null),a=P.useRef(null),o=P.useRef(null),i=P.useRef(!1),s=P.useRef(null),l=P.useRef(!1),c=P.useRef(null),d=P.useRef(null),p=P.useRef(!1),f=P.useRef(null),b=P.useRef(null),[g,y]=P.useState(null),[x,A]=P.useState(null),M=pe(be=>be.spectralData),v=pe(be=>be.viewPort),w=pe(be=>be.setViewPort),R=pe(be=>be.activeTool),k=pe(be=>be.toolSettings),I=qr(R,k),E=pe(be=>be.renderVersion),F=pe(be=>be.triggerRender),L=pe(be=>be.setAudioBufferDirty),B=pe(be=>be.pushUndo),O=pe(be=>be.colorMapName),T=pe(be=>be.playheadPosition),_=pe(be=>be.isPlaying),G=pe(be=>be.showPlayheadMarker),j=pe(be=>be.lineStart),N=pe(be=>be.setLineStart),W=pe(be=>be.waveformMix),V=pe(be=>be.showGrainLayer),U=pe(be=>be.synthMode),H=pe(be=>be.materialExport),q=pe(be=>be.carrierDonorV2.skeleton),K=pe(be=>be.carrierDonorV2.continuityGraph),Y=pe(be=>be.carrierDonorV2.bindingPreview),J=pe(be=>be.carrierDonorV2.overlayVisible),Z=pe(be=>be.carrierDonorV2.continuityOverlayVisible),te=pe(be=>be.carrierDonorV2.bindingOverlayVisible),X=pe(be=>be.carrierDonorV2.freshness),Q=pe(be=>be.sourceAsset),ne=pe(be=>be.forge3EditTarget),ee=ys(),ie=P.useMemo(()=>e!=="forge3"?null:__forgeDisplayVisibility(M,ee),[e,M,ee,Q,E]),de=ie?.active??null,oe=ie?.trace??null,ue=pe(be=>be.stampData),fe=pe(be=>be.stampScaleX),he=pe(be=>be.stampScaleY),re=pe(be=>be.stampRotation),le=pe(be=>be.stampFlipX),Ae=pe(be=>be.stampFlipY),ce=pe(be=>be.stampPhase),ge=pe(be=>be.setStampData),Ce=pe(be=>be.setStampScale),Re=pe(be=>be.setStampPhase),se=pe(be=>be.stampSelStart),xe=pe(be=>be.setStampSelStart),Be=pe(be=>be.setGuideMarker),Ie=P.useRef(bE(xO[O])); P.useEffect(()=>{Ie.current=bE(xO[O])},[O]),P.useEffect(()=>{e==="forge3"&&ee.ensureInitialized(M,pe.getState().sourceAssetContext==="forge3_main"?Q:null)},[e,M,Q,ee]);const Qe=e==="forge3"&&!!Q&&pe.getState().sourceAssetContext==="forge3_main"&&ne==="linked_body",Ne=P.useCallback((be,ve)=>{const Je=r.current;if(!Je)return{x:0,y:0};const Oe=Je.getBoundingClientRect(),Xe=be-Oe.left,it=ve-Oe.top,Ze=Math.floor(Xe/v.zoomX+v.offsetX),st=Math.floor(it/v.zoomY+v.offsetY);return{x:Ze,y:st}},[v]),Ue=P.useCallback(()=>{const be=Math.max(1,H.bars||1),ve=M.width/be,Je=(H.guideMarkers||[]).filter(Oe=>Number.isFinite(Oe));return{safeBars:be,barWidthData:ve,guideMarkers:Je}},[H.bars,H.guideMarkers,M.width]),Ye=P.useCallback((be,ve)=>{const Je=r.current;if(!Je)return null;const Oe=Je.getBoundingClientRect(),Xe=be-Oe.left,it=ve-Oe.top;if(it<0||it>18)return null;const{safeBars:Ze,barWidthData:st,guideMarkers:ht}=Ue();if(ht.length===0)return null;let ft=null;for(let Ot=0;Ot<Ze;Ot++){const un=Ot*st;for(let Xt=0;Xt<ht.length;Xt++){const fn=(un+ht[Xt]*st-v.offsetX)*v.zoomX,Ut=Math.abs(fn-Xe);Ut>10||(!ft||Ut<ft.distance)&&(ft={markerIndex:Xt,barIndex:Ot,distance:Ut})}}return ft},[Ue,v.offsetX,v.zoomX]),Ve=P.useCallback(be=>{const ve=r.current;ve&&D5e({canvas:ve,spectralData:M,renderVersion:pe.getState().renderVersion,viewPort:be??v,colorLut:Ie.current,showGrain:V||U==="granular",variant:e,forge3Lens:t,forge3Field:ee,activeVisibilityMask:de,traceVisibilityMask:oe,showTraceLayer:n})},[M,v,V,U,e,t,ee,de,oe,n]),tt=P.useMemo(()=>{const be=new Map;if(!q)return be;for(const ve of q.anchorsByTime)for(const Je of ve)be.set(Je.id,Je);return be},[q]),dt=P.useMemo(()=>{const be=new Map;for(const ve of Y)be.set(ve.carrierAnchorId,ve);return be},[Y]),gt=P.useMemo(()=>J?X.skeletonMeta.status==="dirty"?"Carrier overlay still shows the previous analysis — updating.":te&&X.bindingMeta.status==="dirty"?"Assignment rings still show the previous mapping — updating.":Z&&X.continuityMeta.status==="dirty"?"Continuity lines still show the previous carrier reading — updating.":"":"",[J,te,Z,X]);function Ge(be,ve){const Je=pe.getState().viewPort;return{x:Math.floor(be/Je.zoomX+Je.offsetX),y:Math.floor(ve/Je.zoomY+Je.offsetY)}}const Te=P.useCallback(()=>{N5e({canvas:a.current,viewPort:v,spectralData:M,activeTool:R,lineStart:j,toolSettings:I,stampPhase:ce,stampSelStart:se,stampSelEnd:f.current,stampData:ue,stampScaleX:fe,stampScaleY:he,stampRotation:re,stampFlipX:le,stampFlipY:Ae,mousePos:d.current,guideDragMarkerIndex:b.current?.markerIndex??null,guideLayout:Ue(),colorLut:Ie.current,showGrainLayer:V,synthMode:U,showPlayheadMarker:G,isPlaying:_,playheadPosition:T,showCarrierDonorV2Overlay:J,showCarrierDonorV2ContinuityOverlay:Z,showCarrierDonorV2BindingOverlay:te,carrierDonorV2Skeleton:q,carrierDonorV2ContinuityGraph:K,carrierAnchorMap:tt,carrierBindingMap:dt,v2OverlayWarning:gt,screenToDataFromScreen:Ge})},[v,M,R,j,I,ce,se,ue,fe,he,re,le,Ae,V,U,Ue,G,_,T,J,Z,te,q,K,tt,dt,gt]);t4e({mainCanvasRef:r,spectralWidth:M.width,viewPort:v,setViewPort:w,isPlaying:_,playheadPosition:T,renderVersion:E,renderMain:Ve,renderOverlay:Te});const{overviewWrapRef:rt,overviewCanvasRef:lt,onNavigatorMouseDown:ut}=e4e({mainCanvasRef:r,colorLUTRef:Ie,spectralData:M,viewPort:v,setViewPort:w,renderVersion:E,showGrainLayer:V,synthMode:U,playheadPosition:T,isPlaying:_,showPlayheadMarker:G});n4e({containerRef:o,mainCanvasRef:r,overlayCanvasRef:a,spectralWidth:M.width,spectralHeight:M.height,setViewPort:w,renderMain:Ve,autoFitY:!!v.autoFitY,viewZoomY:v.zoomY,viewPort:v});P.useEffect(()=>{const canvas=r.current;if(!canvas||canvas.width<2)return;const current=pe.getState().viewPort,next=__forgeClampHorizontalViewport(current,canvas.width,M.width);if(Math.abs(next.zoomX-current.zoomX)>.0001||Math.abs(next.offsetX-current.offsetX)>.0001)w({zoomX:next.zoomX,offsetX:next.offsetX})},[M.width,v.zoomX,v.offsetX,v.spanX,v.startX,v.autoFitX,w]);const at=P.useCallback((be,ve,Je,Oe="reseed")=>{e==="forge3"&&ee.syncRegionFromSpectralData(M,be,ve,Je,Oe)},[e,ee,M]),qe=P.useCallback(be=>{I5e({spectralData:M,activeTool:R,defaultBrushSize:I.brushSize??1,dirty:be,ports:{invalidateAudioBuffer:()=>xt.invalidateBuffer(),setAudioBufferDirty:L,triggerRender:F}})},[R,I.brushSize,M,L,F]),mt=P.useCallback((be,ve)=>{F5e({activeTool:R,spectralData:M,settings:I,forge3Mode:e==="forge3",bodyLinkedMode:Qe,sourceAsset:Q,forge3Field:ee,syncForge3Region:at,x:be,y:ve}),qe({x:be,y:ve,radius:I.brushSize,reason:`spectral-forge-${R}-paint`})},[R,Qe,ee,Q,I,M,at,qe,e]),It=P.useCallback(be=>{if(be.button===0){const Je=Ye(be.clientX,be.clientY);if(Je){b.current={markerIndex:Je.markerIndex,barIndex:Je.barIndex};return}}if(be.button===1||be.button===0&&be.altKey){l.current=!0,c.current={x:be.clientX,y:be.clientY,ox:v.offsetX,oy:v.offsetY};return}if(be.button!==0)return;const ve=Ne(be.clientX,be.clientY);if(R==="stamp"){if(ce==="idle"||ce==="selecting"){const stampStart=__f35616StampBoundary(be.clientX,be.clientY,r.current,Ne,M.width,M.height,!1);xe(stampStart),Re("selecting"),p.current=!0,f.current=stampStart;return}if(ce==="stamping"&&ue){B(),M.pasteStamp(ve.x,ve.y,ue,I.intensity,I.eraseMode,{scaleX:fe,scaleY:he,rotation:re,flipX:le,flipY:Ae}),Qe?(ee.pasteCapturedStampMetadata(M,ue,ve.x,ve.y,I.intensity,I.eraseMode,{scaleX:fe,scaleY:he,rotation:re,flipX:le,flipY:Ae}),at(ve.x,ve.y,Math.max(ue.width,ue.height)*.6,"preserve")):at(ve.x,ve.y,Math.max(ue.width,ue.height)*.6),qe({x:ve.x,y:ve.y,radius:Math.max(ue.width,ue.height)*Math.max(fe,he,1)*.6,reason:"spectral-forge-stamp-paste"});return}return}if(R==="line"){if(!j)N(ve);else{B();const{brushSize:Je,intensity:Oe,hardness:Xe,eraseMode:it,grainSize:Ze}=I;M.drawLine(j.x,j.y,ve.x,ve.y,Je,Oe,Xe,"brush",it,.3,Ze),e==="forge3"&&at(ve.x,ve.y,Je),qe({x0:Math.min(j.x,ve.x)-Je,x1:Math.max(j.x,ve.x)+Je,y0:Math.min(j.y,ve.y)-Je,y1:Math.max(j.y,ve.y)+Je,reason:"spectral-forge-line-edit"}),N(null)}return}if(R==="morph"){i.current=!0,s.current=ve,B(),I.morphMode!=="push"&&(e==="forge3"&&Q?(ee.applyMorph(M,ve.x,ve.y,I.brushSize,I.intensity,I.morphMode,0,0),at(ve.x,ve.y,I.brushSize,"preserve")):(M.applyMorph(ve.x,ve.y,I.brushSize,I.intensity,I.morphMode,0,0),e==="forge3"&&at(ve.x,ve.y,I.brushSize)),qe({x:ve.x,y:ve.y,radius:I.brushSize,reason:"spectral-forge-morph-edit"}));return}if(R==="smudge"){i.current=!0,s.current=ve,B(),M.applySmudge(ve.x,ve.y,I.brushSize,I.intensity*.6,0,0,I.grainSize),e==="forge3"&&at(ve.x,ve.y,I.brushSize),qe({x:ve.x,y:ve.y,radius:I.brushSize,reason:"spectral-forge-smudge-edit"});return}i.current=!0,s.current=ve,B(),mt(ve.x,ve.y)},[Ne,R,Qe,j,N,B,mt,I,M,qe,v,ce,ue,fe,he,re,le,Ae,xe,Re,ge,Ye,ee,at,e]),Ct=P.useCallback(be=>{const ve=r.current;if(!ve)return;const Je=ve.getBoundingClientRect();d.current={sx:be.clientX-Je.left,sy:be.clientY-Je.top};const Oe=Ne(be.clientX,be.clientY),Xe=hs(Oe.y,M.height)*__f3565PitchRatio(),it=Oe.x/M.width*Ar;if(y({freq:Math.round(Xe*10)/10,time:Math.round(it*1e3)/1e3,note:NFe(Xe)}),e==="forge3"){const st=ee.describeCell(Oe.x,Oe.y);A(st?`${t==="body"?"Body":t==="source"?"Source":"Listen"} · Class: ${st.classLabel} · Source ${(st.sourceWeight*100).toFixed(0)}% · t ${(st.sourceTime*100).toFixed(0)} · b ${(st.sourceBand*100).toFixed(0)}`:null)}else x&&A(null);if(b.current){const{barWidthData:st,guideMarkers:ht}=Ue(),ft=b.current,Ot=ft.barIndex*st,un=(Oe.x-Ot)/Math.max(1,st),Xt=ft.markerIndex===0?0:ht[ft.markerIndex-1]??0,hn=ft.markerIndex===ht.length-1?1:ht[ft.markerIndex+1]??1,fn=1/(Math.max(1,H.guideSegments)*8),Ut=Math.max(Xt+fn,Math.min(hn-fn,un));Be(ft.markerIndex,Ut);return}if(p.current&&R==="stamp"){f.current=__f35616StampBoundary(be.clientX,be.clientY,r.current,Ne,M.width,M.height,!0);return}if(l.current&&c.current){const st=(be.clientX-c.current.x)/v.zoomX,ht=(be.clientY-c.current.y)/v.zoomY;w({offsetX:Math.max(0,c.current.ox-st),offsetY:Math.max(0,c.current.oy-ht),autoFitY:false});return}if(!i.current)return;const Ze=s.current;if(Ze){const{brushSize:st,intensity:ht,hardness:ft,eraseMode:Ot,sprayDensity:un,grainSize:Xt}=I,hn=Oe.x-Ze.x,fn=Oe.y-Ze.y,Ut=Math.max(Math.abs(hn),Math.abs(fn),1),He=Math.max(1,Math.floor(Math.max(1,st)*.35));if(R==="morph"){const _e=Oe.x-Ze.x,ot=Oe.y-Ze.y;Qe?ee.applyMorph(M,Oe.x,Oe.y,st,ht,I.morphMode,_e,ot):(M.applyMorph(Oe.x,Oe.y,st,ht,I.morphMode,_e,ot),e==="forge3"&&at(Oe.x,Oe.y,st))}else if(R==="smudge"){const _e=Oe.x-Ze.x,ot=Oe.y-Ze.y;M.applySmudge(Oe.x,Oe.y,st,ht,_e,ot,Xt)}else if(R==="dodgeBurn")for(let _e=0;_e<=Ut;_e+=He){const ot=_e/Ut,kt=Math.round(Ze.x+hn*ot),Ke=Math.round(Ze.y+fn*ot);M.applyDodgeBurn(kt,Ke,st,ht,ft,Ot,Xt)}else if(R==="blurSharpen")for(let _e=0;_e<=Ut;_e+=He){const ot=_e/Ut,kt=Math.round(Ze.x+hn*ot),Ke=Math.round(Ze.y+fn*ot);M.applyBlurSharpen(kt,Ke,st,ht,ft,Ot)}else if(R==="delaySmear")for(let _e=0;_e<=Ut;_e+=He){const ot=_e/Ut,kt=Math.round(Ze.x+hn*ot),Ke=Math.round(Ze.y+fn*ot);M.applyDelaySmear(kt,Ke,st,ht,ft,Ot,Xt)}else if(R==="threshold")for(let _e=0;_e<=Ut;_e+=He){const ot=_e/Ut,kt=Math.round(Ze.x+hn*ot),Ke=Math.round(Ze.y+fn*ot);M.applyThresholdBrush(kt,Ke,st,ht,ft,Ot,Xt)}else if(R==="sourceTrace"){const _e=Q?.analysisCache;if(_e){for(let ot=0;ot<=Ut;ot+=He){const kt=ot/Ut,Ke=Math.round(Ze.x+hn*kt),Mt=Math.round(Ze.y+fn*kt);M.applySourceTrace(Ke,Mt,st,ht,ft,_e.data,_e.width,_e.height,_e.transientEnvelope,Ot,Xt),Qe&&Q&&ee.applySourceTraceMetadata(M,Q,Ke,Mt,st,ht,ft,Ot)}at(Oe.x,Oe.y,st)}}else if(R==="harmonicBrush")for(let _e=0;_e<=Ut;_e+=He){const ot=_e/Ut,kt=Math.round(Ze.x+hn*ot),Ke=Math.round(Ze.y+fn*ot);M.applyHarmonicBrush(kt,Ke,st,ht*.5,ft,I.numHarmonics,I.harmonicDecay,M.height,Ot,Xt)}else if(R==="formant")for(let _e=0;_e<=Ut;_e+=He){const ot=_e/Ut,kt=Math.round(Ze.x+hn*ot),Ke=Math.round(Ze.y+fn*ot);M.applyFormantStamp(kt,Ke,I.formantVowel,ht,M.height,st,Ot,Xt)}else if(R==="noiseBrush")for(let _e=0;_e<=Ut;_e+=He){const ot=_e/Ut,kt=Math.round(Ze.x+hn*ot),Ke=Math.round(Ze.y+fn*ot);M.applyNoiseBrush(kt,Ke,st,ht,Ot,Xt)}else if(R==="hardBrush")if(Qe)for(let _e=0;_e<=Ut;_e+=He){const ot=_e/Ut,kt=Math.round(Ze.x+hn*ot),Ke=Math.round(Ze.y+fn*ot);ee.applySteinmetz(M,kt,Ke,st,ht,Ot,Xt)}else M.drawLine(Ze.x,Ze.y,Oe.x,Oe.y,st,ht,1,"brush",Ot,un,Xt);else R==="spray"?M.drawLine(Ze.x,Ze.y,Oe.x,Oe.y,st,ht,ft,"spray",Ot,un,Xt):M.drawLine(Ze.x,Ze.y,Oe.x,Oe.y,st,ht,ft,"brush",Ot,un,Xt);if(e==="forge3"){const _e=R==="morph"&&Qe||R==="sourceTrace"&&Qe||R==="hardBrush"&&Qe?"preserve":"reseed";at(Oe.x,Oe.y,st,_e)}qe({x0:Math.min(Ze.x,Oe.x)-st,x1:Math.max(Ze.x,Oe.x)+st,y0:Math.min(Ze.y,Oe.y)-st,y1:Math.max(Ze.y,Oe.y)+st,reason:`spectral-forge-${R}-drag`})}s.current=Oe},[Ne,v,w,R,Qe,Q,I,M,qe,Ue,H.guideSegments,Be,ee,at,e,x,t]),St=P.useCallback(be=>{if(p.current&&R==="stamp"&&se){p.current=!1;const ve=__f35616StampBoundary(be.clientX,be.clientY,r.current,Ne,M.width,M.height,!0),Je=Math.min(se.x,ve.x),Oe=Math.min(se.y,ve.y),Xe=Math.abs(ve.x-se.x),it=Math.abs(ve.y-se.y);if(Xe>1&&it>1){Qe&&ee.captureStampMeta(Je,Oe,Xe,it);const Ze=I.eraseMode?(()=>{B();const st=M.cutRegion(Je,Oe,Xe,it);return Qe&&ee.excavateCapturedRegion(Je,Oe,Xe,it),qe({x0:Je,x1:Je+Xe,y0:Oe,y1:Oe+it,reason:"spectral-forge-stamp-cut"}),st})():M.copyRegion(Je,Oe,Xe,it);ge(Ze),Ce(1,1),Re("stamping")}else Re("idle");xe(null),f.current=null}b.current=null,i.current=!1,s.current=null,l.current=!1,c.current=null},[R,se,M,I.eraseMode,B,qe,ge,Ce,Re,xe,Ne,ee,e]),At=P.useCallback(be=>{if(p.current&&R==="stamp"){f.current=__f35616StampBoundary(be.clientX,be.clientY,r.current,Ne,M.width,M.height,!0);return}d.current=null,b.current=null,i.current=!1,s.current=null,l.current=!1,c.current=null,p.current&&(p.current=!1,f.current=null,pe.getState().setStampSelStart(null),pe.getState().setStampPhase("idle"))},[R,Ne,M.width,M.height]);P.useEffect(()=>{const track=event=>{if(!p.current||pe.getState().activeTool!=="stamp")return;const canvas=r.current;if(!canvas)return;const box=canvas.getBoundingClientRect();if(event.clientX<box.left||event.clientX>=box.right||event.clientY<box.top||event.clientY>=box.bottom)Ct(event)},finish=event=>{if(p.current&&pe.getState().activeTool==="stamp")St(event)};window.addEventListener("mousemove",track);window.addEventListener("mouseup",finish);return()=>{window.removeEventListener("mousemove",track);window.removeEventListener("mouseup",finish)}},[Ct,St]);P.useEffect(()=>{const be=o.current;if(!be)return;let ve=0,Je=null;const Oe=()=>{Je=null;const it=Math.max(-JO,Math.min(JO,ve));if(ve=0,Math.abs(it)<.01)return;const Ze=pe.getState();if(Ze.activeTool!=="stamp"||Ze.stampPhase!=="stamping")return;const st=Math.exp(-it*W5e);Ze.setStampScale(ZO(Ze.stampScaleX*st),ZO(Ze.stampScaleY*st))},Xe=it=>{it.preventDefault(),it.stopPropagation();const Ze=pe.getState();if(Ze.activeTool==="stamp"&&Ze.stampPhase==="stamping"){ve+=X5e(it),Je===null&&(Je=window.requestAnimationFrame(Oe));return}};return be.addEventListener("wheel",Xe,{passive:!1,capture:!0}),()=>{be.removeEventListener("wheel",Xe,!0),Je!==null&&window.cancelAnimationFrame(Je)}},[]);const Et=P.useCallback(be=>{const ve=Ne(be.clientX,be.clientY);pe.getState().setShowPlayheadMarker(!1),xt.previewColumn(M,ve.x,W,300)},[Ne,M,W]),Se=P.useCallback(be=>{be.preventDefault(),R==="stamp"&&(Re("idle"),ge(null),xe(null),f.current=null,p.current=!1),R==="line"&&j&&N(null)},[R,Re,ge,xe,j,N]);return u.jsxs("div",{className:"grid flex-1 min-h-0 grid-rows-[minmax(0,1fr)_auto] bg-black",children:[u.jsxs("div",{className:"relative min-h-[300px] overflow-hidden",ref:o,style:{touchAction:"none",overscrollBehavior:"contain"},children:[u.jsx("canvas",{ref:r,"data-forge-carrier-canvas":e==="forge3"?"true":undefined,className:"absolute inset-0",style:{imageRendering:"auto"}}),e==="forge3"&&u.jsx(ForgePCMSpectrumView,{frame:{canvasRef:r,spectralData:M,renderVersion:E,viewPort:v,colorLut:Ie.current,showGrain:V||U==="granular",variant:e,forge3Lens:t,forge3Field:ee,activeVisibilityMask:de,traceVisibilityMask:oe,showTraceLayer:n}}),u.jsx("canvas",{ref:a,className:"absolute inset-0 pointer-events-none"}),u.jsx("div",{className:"absolute inset-0",style:{cursor:"none",touchAction:"none"},onMouseDown:It,onMouseMove:Ct,onMouseUp:St,onMouseLeave:At,onDoubleClick:Et,onContextMenu:Se}),u.jsx(__f375ForgeMainSelectionHandles,{mainCanvasRef:r,spectralWidth:M.width,viewPort:v}),u.jsx(O5e,{hoverInfo:g,forge3Hover:x,eraseMode:I.eraseMode}),u.jsx(_5e,{isPlaying:_,playheadPosition:T,variant:e,forge3Lens:t}),u.jsx(z5e,{activeTool:R,stampPhase:ce,stampScaleX:fe,stampScaleY:he}),u.jsx(j5e,{spectralHeight:M.height,viewPort:v,canvasHeight:r.current?.height})]}),u.jsx(G5e,{overviewWrapRef:rt,overviewCanvasRef:lt,viewPort:v,onNavigatorMouseDown:ut})]})}