# Scrollbar restore patch

Patched from `Xensonar_loop_refine_viewblend_patch.zip`.

## Change made
- `src/index.css`
  - restored vertical page scrolling chrome by changing global shell from `overflow: hidden;` to:
    - `overflow-x: hidden;`
    - `overflow-y: scroll;`
    - `overscroll-behavior: none;`

## Intention
- keep wheel / trackpad gestures blocked by the app-level handler
- restore the visible right scrollbar so scrolling can happen deliberately via the scrollbar
- avoid reopening the earlier regression where the whole page could drift from touchpad gestures over the main surfaces

## Verification
- `vite build` passed
- `tsc --noEmit` passed
