# Xensonar 20a – pragmatische Modularisierung

## Ziel
Die Grundlogik des Instruments bleibt gekoppelt, aber die deklarativen Daten und die pure Ableitungslogik werden aus `App.tsx` herausgezogen.

## Was jetzt ausgelagert wurde

### 1. Musikalische Domäne / deklarative Daten
`src/features/xensonar/domain/instrumentData.ts`

Enthält jetzt:
- Tuning-/Preset-/Pattern-Typen
- statische Optionslisten
- musikalische Konstanten (`JI_NODES`, `PRESET_MAP`, Obertöne, Keyboard-Mapping-Konstanten)
- pure Hilfsfunktionen wie `deriveModeMask`, `nextGridTuning`, `getParticleNodes`, `createEmptyOvertoneMix`, `cloneOvertoneMixByPreset`

### 2. Meta-Presets
`src/features/xensonar/domain/metaPresets.ts`

Enthält jetzt:
- `MetaPresetId`
- `MetaPresetDefinition`
- `META_PRESETS`
- `createMetaOvertoneMix`

Damit sitzen die Meta-Presets nicht mehr in der TSX selbst.

### 3. Laufzeit-Typen
`src/features/xensonar/domain/runtimeTypes.ts`

Enthält die nicht-musikalischen Strukturen für:
- Raum-/Arena-/Nexus-Objekte
- Recording-Typen
- Ripple-/Pulse-/Grid-Typen

### 4. Topologische Signatur
`src/features/topology/constellationSignature.ts`

Enthält jetzt die pure Ableitung der Sternbild-Signatur aus Node-Geometrie.

### 5. Resonanz-/Weave-Mathematik
`src/features/resonance/weaveMath.ts`

Enthält jetzt:
- `parseJiRatioLabel`
- `getDominantDroneRatios`
- `getWeaveMatch`

### 6. Interpreter-Grundkonfiguration
`src/features/resonance/interpreterConfig.ts`

Enthält jetzt:
- `MyzelInterpreterMix`
- `DEFAULT_MYZEL_INTERPRETER_MIX`
- `MYZEL_INTERPRETER_TARGETS`
- Basisfrequenz-Auflösung für den Interpreterpfad (`resolveInterpreterMyzelBaseHz`)

## Was bewusst gekoppelt blieb

Diese Dinge sind absichtlich noch nicht in voneinander getrennte Mini-Module zerfallen:
- der zentrale Audio-Graph
- Scheduler / laufende Timing-Logik
- Snapshot-Erzeugung in der Runtime
- direkte React-/Runtime-Orchestrierung in `App.tsx`

Der Grund: Genau dort sitzt momentan noch reale Klangkopplung. Ein zu früher Vollschnitt würde eher Verhalten auseinanderziehen als Ordnung schaffen.

## Ergebnis
`App.tsx` ist noch groß, aber die schwersten semantischen Blöcke sind jetzt benannt und ausgelagert:
- Datenwelt
- Presetwelt
- Topologiesignatur
- Resonanz-Weave-Mathematik
- Interpreter-Basislogik

Das ist eine belastbare Zwischenstufe für den nächsten Schritt:

**mehrere Myzel-Interpreter als Registry**, die gezielt auf
- Drone,
- Myzel-Voice,
- Particle-Hits,
- Wave-Starter,
- Distortion

geroutet werden können, ohne dass jeder Pfad seinen eigenen „privaten“ Myzel-Zustand erfindet.
