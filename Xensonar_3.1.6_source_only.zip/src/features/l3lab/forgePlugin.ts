import type { ReactNode } from 'react';
import type { XensonarMaterialRole } from './materialSchema';

export interface XensonarForgePluginCapabilities {
  canExportLoop: boolean;
  canExportWaveMaterial: boolean;
  canExportParticleExciter: boolean;
  canExportDroneTexture: boolean;
}

export interface XensonarForgePluginRenderProps {
  onFocus?(): void;
}

export interface XensonarForgePlugin {
  pluginId: string;
  pluginName: string;
  version: string;
  capabilities: XensonarForgePluginCapabilities;
  supportedRoles: XensonarMaterialRole[];
  renderRoom(props: XensonarForgePluginRenderProps): ReactNode;
}
