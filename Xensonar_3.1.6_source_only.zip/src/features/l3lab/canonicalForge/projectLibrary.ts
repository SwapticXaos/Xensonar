import { useSyncExternalStore } from 'react';
import type { AudioSourceAsset } from '../spectralForge/audio/AudioImporter';
import type { CanonicalForgeSessionState } from './session';

type Listener = () => void;

export interface CanonicalForgeProjectMeta {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  bpm: number;
  bars: number;
  activeTool: CanonicalForgeSessionState['activeTool'];
  hasSourceAudio: boolean;
  sourceDurationSec: number | null;
}

export interface CanonicalForgeProjectSnapshot extends Omit<CanonicalForgeSessionState, 'rawSourceAsset' | 'sourceAsset' | 'bundle' | 'status'> {
  sourceAsset: AudioSourceAsset | null;
}

export interface CanonicalForgeProjectRecord extends CanonicalForgeProjectMeta {
  snapshot: CanonicalForgeProjectSnapshot;
}

type CanonicalProjectLibraryState = { entries: CanonicalForgeProjectMeta[] };

const DB_NAME = 'xensonar-canonical-forge-projects';
const STORE_NAME = 'canonicalForgeProjects';
const MAX_PROJECTS = 64;

let state: CanonicalProjectLibraryState = { entries: [] };
const listeners = new Set<Listener>();
let hydrationStarted = false;

function emit() {
  listeners.forEach((listener) => listener());
}

function metaFromRecord(record: CanonicalForgeProjectRecord): CanonicalForgeProjectMeta {
  return {
    id: record.id,
    name: record.name,
    createdAt: record.createdAt,
    updatedAt: record.updatedAt,
    bpm: record.bpm,
    bars: record.bars,
    activeTool: record.activeTool,
    hasSourceAudio: !!record.snapshot.sourceAsset,
    sourceDurationSec: record.snapshot.sourceAsset?.originalDuration ?? null,
  };
}

function setEntries(entries: CanonicalForgeProjectMeta[]) {
  state = {
    entries: [...entries].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, MAX_PROJECTS),
  };
  emit();
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB not available'));
      return;
    }
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error('Failed to open canonical forge project DB'));
  });
}

async function loadPersistedEntries() {
  if (typeof indexedDB === 'undefined') return;
  const db = await openDb();
  const records = await new Promise<CanonicalForgeProjectRecord[]>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const request = store.getAll();
    request.onsuccess = () => resolve((request.result as CanonicalForgeProjectRecord[]) ?? []);
    request.onerror = () => reject(request.error ?? new Error('Failed to load canonical forge projects'));
  });
  setEntries(records.map(metaFromRecord));
}

function ensureHydrated() {
  if (hydrationStarted) return;
  hydrationStarted = true;
  void loadPersistedEntries().catch((error) => {
    console.warn('[xensonar][canonical-forge-project-library][hydrate]', error);
  });
}

export function useCanonicalForgeProjectLibrary<U = CanonicalProjectLibraryState>(selector?: (snapshot: CanonicalProjectLibraryState) => U): U {
  ensureHydrated();
  const select = selector ?? ((snapshot: CanonicalProjectLibraryState) => snapshot as unknown as U);
  return useSyncExternalStore(
    (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    () => select(state),
    () => select(state),
  );
}

async function loadProjectRecord(id: string): Promise<CanonicalForgeProjectRecord> {
  const db = await openDb();
  const record = await new Promise<CanonicalForgeProjectRecord | null>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readonly');
    const store = tx.objectStore(STORE_NAME);
    const request = store.get(id);
    request.onsuccess = () => resolve((request.result as CanonicalForgeProjectRecord | null) ?? null);
    request.onerror = () => reject(request.error ?? new Error('Failed to load canonical forge project'));
  });
  if (!record) throw new Error('Projekt nicht gefunden');
  return record;
}

export async function saveCanonicalForgeProject(args: {
  id?: string;
  name: string;
  snapshot: CanonicalForgeProjectSnapshot;
}): Promise<CanonicalForgeProjectMeta> {
  const db = await openDb();
  const now = Date.now();
  const existing = args.id ? await loadProjectRecord(args.id).catch(() => null) : null;
  const record: CanonicalForgeProjectRecord = {
    id: args.id ?? crypto.randomUUID(),
    name: args.name.trim() || 'canonical-forge-project',
    createdAt: existing?.createdAt ?? now,
    updatedAt: now,
    bpm: args.snapshot.materialExport.bpm,
    bars: args.snapshot.materialExport.bars,
    activeTool: args.snapshot.activeTool,
    hasSourceAudio: !!args.snapshot.sourceAsset,
    sourceDurationSec: args.snapshot.sourceAsset?.originalDuration ?? null,
    snapshot: args.snapshot,
  };

  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const request = store.put(record);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error ?? new Error('Failed to save canonical forge project'));
  });

  const meta = metaFromRecord(record);
  const nextEntries = [meta, ...state.entries.filter((entry) => entry.id !== record.id)];
  setEntries(nextEntries);
  return meta;
}

export async function loadCanonicalForgeProject(id: string): Promise<CanonicalForgeProjectRecord> {
  return loadProjectRecord(id);
}

export async function renameCanonicalForgeProject(id: string, name: string): Promise<CanonicalForgeProjectMeta> {
  const existing = await loadProjectRecord(id);
  existing.name = name.trim() || existing.name;
  existing.updatedAt = Date.now();

  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const request = store.put(existing);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error ?? new Error('Failed to rename canonical forge project'));
  });

  const meta = metaFromRecord(existing);
  setEntries([meta, ...state.entries.filter((entry) => entry.id !== id)]);
  return meta;
}

export async function deleteCanonicalForgeProject(id: string): Promise<void> {
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const request = store.delete(id);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error ?? new Error('Failed to delete canonical forge project'));
  });
  setEntries(state.entries.filter((entry) => entry.id !== id));
}
