import type { AudioSourceAsset } from '../spectralForge/audio/AudioImporter';
import type { StampData, MorphMode } from '../spectralForge/audio/SpectralData';
import type { CanonicalAnalysisBundle, CanonicalSourceView } from './analysis';

export type CanonicalTool = 'brush' | 'smudge' | 'morph' | 'sourceTrace' | 'harmonicLift' | 'transientLift' | 'noiseGate' | 'dodgeBurn' | 'blurSharpen' | 'delaySmear' | 'threshold' | 'stamp';
export type CanonicalSynthMode = 'additive' | 'ifft' | 'granular' | 'glyph';
export type CanonicalMaterialRole = 'loop' | 'waveMaterial' | 'particleExciter' | 'droneTexture';
export type CanonicalSourcePreviewMode = 'forge' | 'sourceWindow' | 'sourceFull';
export type CanonicalForgeWorkspace = 'wave-material' | 'microtonal-logic';
export type CanonicalLogicView = 'drums' | 'melodic';
export type CanonicalTransferMode = 'forge-render' | 'source-direct';

export type CanonicalMaterialExportConfig = {
  name: string;
  role: CanonicalMaterialRole;
  adapterId: string;
  bpm: number;
  bars: number;
  guideSegments: number;
  guideMarkers: number[];
  beatGuideAudible: boolean;
  beatGuideVolume: number;
  loopPreview: boolean;
  transferMode?: CanonicalTransferMode;
};

export type WaveformMix = {
  sine: number;
  sawtooth: number;
  square: number;
  triangle: number;
};

export type CanonicalToolSettings = {
  brushSize: number;
  intensity: number;
  hardness: number;
  eraseMode: boolean;
  morphMode: MorphMode;
};



export type CanonicalLoopPitchStep = {
  id: string;
  label: string;
  ratio: number;
  cents: number;
  offsetCents: number;
  muted: boolean;
};

export type CanonicalLoopTrack = {
  id: string;
  label: string;
  color: string;
  volume: number;
  instrumentRole: 'bass' | 'companion' | 'aux';
  instrumentPreset?: 'subPulse' | 'acidSquare' | 'reedTone' | 'glassPad' | 'airPluck' | 'metalBloom';
  pan?: number;
  enabled: boolean;
};

export type CanonicalLoopNoteEvent = {
  id: string;
  trackId: string;
  stepId: string;
  octaveOffset: number;
  startStep: number;
  lengthSteps: number;
  fadeInSteps: number;
  fadeOutSteps: number;
  velocity: number;
};

export type CanonicalLoopComposerState = {
  pitchSteps: CanonicalLoopPitchStep[];
  tracks: CanonicalLoopTrack[];
  notes: CanonicalLoopNoteEvent[];
  selectedTrackId: string;
  selectedNoteId: string | null;
  stepsPerBar: number;
  bars: number;
  zoom: number;
  scrollX: number;
  activeTrackIds: string[];
};

export type CanonicalDrumVoiceId = 'kick' | 'snare' | 'hatClosed' | 'hatOpen' | 'clap' | 'perc';

export type CanonicalDrumComputerState = {
  useCustom: boolean;
  presetSource: string;
  bars: number;
  stepCount: number;
  laneOrder: CanonicalDrumVoiceId[];
  laneSteps: Record<CanonicalDrumVoiceId, number[]>;
};

export type CanonicalForgeSessionState = {
  materialExport: CanonicalMaterialExportConfig;
  rawSourceAsset: AudioSourceAsset | null;
  sourceAsset: AudioSourceAsset | null;
  bundle: CanonicalAnalysisBundle | null;
  spectralSnapshot: Float32Array | null;
  sourceView: CanonicalSourceView;
  secondaryView: CanonicalSourceView | 'none';
  viewBlend: number;
  activeTool: CanonicalTool;
  toolSettings: CanonicalToolSettings;
  synthMode: CanonicalSynthMode;
  waveformMix: WaveformMix;
  status: string;
  stampPresetId: string;
  stampData: StampData | null;
  stampScaleX: number;
  stampScaleY: number;
  stampRotation: number;
  stampFlipX: boolean;
  stampFlipY: boolean;
  selectionStartSec: number;
  selectionDurationSec: number;
  selectionDirty: boolean;
  detailSelectionStartSec?: number;
  detailSelectionDurationSec?: number;
  detailSelectionDirty?: boolean;
  detailViewportStartSec?: number;
  detailViewportDurationSec?: number;
  detailZoom: number;
  detailOffset: number;
  auditionView?: CanonicalSourceView | 'none';
  auditionBlendAmount?: number;
  selectedProjectId: string | null;
  sourcePreviewMode: CanonicalSourcePreviewMode;
  activeWorkspace?: CanonicalForgeWorkspace;
  logicView?: CanonicalLogicView;
  grooveMachine: {
    drumPattern: string;
    drumKit: string;
    bassPattern: string;
    barsInterpretation: number;
    showGrid: boolean;
  };
  drumComputer?: CanonicalDrumComputerState;
  loopComposer: CanonicalLoopComposerState;
  selectedLoopNoteIds?: string[];
  autoZoomOnDenseOverlap?: boolean;
  lockTrackEditing?: boolean;
  chordVoicing?: 'triad' | 'quartal' | 'cluster' | 'open5';
  chordStrumSteps?: number;
  chordVelocitySlope?: number;
};

let cachedSession: CanonicalForgeSessionState | null = null;

export function getCanonicalForgeSession(): CanonicalForgeSessionState | null {
  return cachedSession;
}

export function setCanonicalForgeSession(next: CanonicalForgeSessionState | null) {
  cachedSession = next;
}
