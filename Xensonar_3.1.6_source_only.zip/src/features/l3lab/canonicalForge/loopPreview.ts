import type { CanonicalDrumComputerState, CanonicalDrumVoiceId, CanonicalLoopComposerState, CanonicalLoopNoteEvent, CanonicalLoopTrack } from './session';
import { createDrumMachine } from '../../resonance/drumMachine';
import type { DrumKit, DrumPattern } from '../../xensonar/domain/instrumentData';
import { buildVisibleDrumPatternMatrix, isRhythmForgeDrumPattern } from '../../xensonar/drumPatternMachine';

export type LoopTrackInstrumentPreset =
  | 'subPulse'
  | 'acidSquare'
  | 'reedTone'
  | 'glassPad'
  | 'airPluck'
  | 'metalBloom';

export const LOOP_TRACK_INSTRUMENTS: Array<{
  id: LoopTrackInstrumentPreset;
  label: string;
  hint: string;
}> = [
  { id: 'subPulse', label: 'Sub Pulse', hint: 'runder psy-bassiger Grundkörper' },
  { id: 'acidSquare', label: 'Acid Square', hint: 'knurriger, kantiger Treiber' },
  { id: 'reedTone', label: 'Reed Tone', hint: 'nasaler Begleiter mit Körper' },
  { id: 'glassPad', label: 'Glass Pad', hint: 'weichere gläserne Fläche' },
  { id: 'airPluck', label: 'Air Pluck', hint: 'helle, luftige Kurzform' },
  { id: 'metalBloom', label: 'Metal Bloom', hint: 'inharmonisch anschimmernde Spitze' },
];

type PreviewRequest = {
  composer: CanonicalLoopComposerState;
  bpm: number;
  bars: number;
  trackIds: string[];
  noteId?: string | null;
  drumPattern?: DrumPattern;
  drumKit?: DrumKit;
  drumLevel?: number;
  customDrumPattern?: CanonicalDrumComputerState | null;
  onPlayhead?: (stepFloat: number | null) => void;
  onEnded?: () => void;
};

type LiveNode = OscillatorNode | GainNode | BiquadFilterNode | StereoPannerNode | AudioBufferSourceNode;

type InstrumentVoiceDef = {
  oscillators: Array<{ type: OscillatorType; gain: number; detune?: number }>;
  filterType?: BiquadFilterType;
  filterFrequency?: number;
  filterQ?: number;
  attackScale: number;
  releaseScale: number;
  transientGain: number;
  panSpread: number;
  octaveBias?: number;
};

const INSTRUMENT_DEFS: Record<LoopTrackInstrumentPreset, InstrumentVoiceDef> = {
  subPulse: {
    oscillators: [
      { type: 'sine', gain: 0.78 },
      { type: 'sawtooth', gain: 0.22, detune: -4 },
    ],
    filterType: 'lowpass',
    filterFrequency: 920,
    filterQ: 0.5,
    attackScale: 0.08,
    releaseScale: 0.34,
    transientGain: 0.12,
    panSpread: 0.06,
    octaveBias: -1,
  },
  acidSquare: {
    oscillators: [
      { type: 'square', gain: 0.55 },
      { type: 'sawtooth', gain: 0.4, detune: 6 },
    ],
    filterType: 'bandpass',
    filterFrequency: 1200,
    filterQ: 2.5,
    attackScale: 0.04,
    releaseScale: 0.22,
    transientGain: 0.18,
    panSpread: 0.08,
    octaveBias: -1,
  },
  reedTone: {
    oscillators: [
      { type: 'sawtooth', gain: 0.52 },
      { type: 'triangle', gain: 0.34, detune: -3 },
    ],
    filterType: 'bandpass',
    filterFrequency: 980,
    filterQ: 1.6,
    attackScale: 0.06,
    releaseScale: 0.3,
    transientGain: 0.1,
    panSpread: 0.12,
  },
  glassPad: {
    oscillators: [
      { type: 'sine', gain: 0.62 },
      { type: 'triangle', gain: 0.24, detune: 5 },
      { type: 'sine', gain: 0.12, detune: 12 },
    ],
    filterType: 'lowpass',
    filterFrequency: 2800,
    filterQ: 0.2,
    attackScale: 0.18,
    releaseScale: 0.55,
    transientGain: 0.06,
    panSpread: 0.16,
  },
  airPluck: {
    oscillators: [
      { type: 'triangle', gain: 0.45 },
      { type: 'square', gain: 0.16, detune: 7 },
    ],
    filterType: 'highpass',
    filterFrequency: 640,
    filterQ: 0.9,
    attackScale: 0.03,
    releaseScale: 0.18,
    transientGain: 0.2,
    panSpread: 0.2,
    octaveBias: 1,
  },
  metalBloom: {
    oscillators: [
      { type: 'triangle', gain: 0.3 },
      { type: 'sawtooth', gain: 0.18, detune: 19 },
      { type: 'square', gain: 0.14, detune: -17 },
    ],
    filterType: 'highpass',
    filterFrequency: 1100,
    filterQ: 1.7,
    attackScale: 0.02,
    releaseScale: 0.28,
    transientGain: 0.16,
    panSpread: 0.22,
    octaveBias: 1,
  },
};

const DRUM_VOICE_TO_MACHINE: Record<CanonicalDrumVoiceId, 'kick' | 'snare' | 'hat_closed' | 'hat_open' | 'clap' | 'perc'> = {
  kick: 'kick',
  snare: 'snare',
  hatClosed: 'hat_closed',
  hatOpen: 'hat_open',
  clap: 'clap',
  perc: 'perc',
};

let previewCtx: AudioContext | null = null;
let currentNodes: LiveNode[] = [];
let playheadFrame: number | null = null;
let currentToken = 0;

function getContext(): AudioContext {
  if (!previewCtx) previewCtx = new AudioContext({ sampleRate: 44100 });
  return previewCtx;
}

function stopNodes() {
  currentNodes.forEach((node) => {
    try {
      if ('stop' in node && typeof node.stop === 'function') node.stop();
    } catch {}
    try {
      node.disconnect();
    } catch {}
  });
  currentNodes = [];
}

export function stopLoopComposerPreview() {
  currentToken += 1;
  if (playheadFrame != null && typeof cancelAnimationFrame !== 'undefined') {
    cancelAnimationFrame(playheadFrame);
    playheadFrame = null;
  }
  stopNodes();
}

function totalComposerSteps(state: CanonicalLoopComposerState) {
  return Math.max(1, state.stepsPerBar * Math.max(1, state.bars));
}

function baseFrequencyForTrack(track: CanonicalLoopTrack, preset: LoopTrackInstrumentPreset) {
  if (track.instrumentRole === 'bass') return 55;
  if (preset === 'airPluck' || preset === 'metalBloom') return 220;
  return track.instrumentRole === 'companion' ? 110 : 165;
}

function ratioFrequency(track: CanonicalLoopTrack, state: CanonicalLoopComposerState, note: CanonicalLoopNoteEvent) {
  const step = state.pitchSteps.find((entry) => entry.id === note.stepId);
  const preset = track.instrumentPreset ?? 'subPulse';
  const baseHz = baseFrequencyForTrack(track, preset);
  const ratio = step?.ratio ?? 1;
  const cents = (step?.offsetCents ?? 0) / 1200;
  const octave = note.octaveOffset + (INSTRUMENT_DEFS[preset].octaveBias ?? 0);
  return baseHz * ratio * Math.pow(2, octave + cents);
}

function scheduleNote(
  ctx: AudioContext,
  master: GainNode,
  state: CanonicalLoopComposerState,
  note: CanonicalLoopNoteEvent,
  track: CanonicalLoopTrack,
  loopStartSec: number,
  stepDurationSec: number,
) {
  const preset = INSTRUMENT_DEFS[track.instrumentPreset ?? 'subPulse'];
  const noteStart = loopStartSec + note.startStep * stepDurationSec;
  const nominalDur = Math.max(0.04, note.lengthSteps * stepDurationSec);
  const fadeIn = Math.min(nominalDur * 0.8, Math.max(0.002, note.fadeInSteps * stepDurationSec || nominalDur * preset.attackScale));
  const fadeOut = Math.min(nominalDur * 0.8, Math.max(0.006, note.fadeOutSteps * stepDurationSec || nominalDur * preset.releaseScale));
  const noteEnd = noteStart + nominalDur + fadeOut + 0.02;
  const freq = Math.max(20, Math.min(12000, ratioFrequency(track, state, note)));
  const voiceGain = ctx.createGain();
  const panner = ctx.createStereoPanner();
  const pan = Math.max(-1, Math.min(1, (note.startStep / Math.max(1, totalComposerSteps(state) - 1) - 0.5) * preset.panSpread * 2 + (track.pan ?? 0)));
  panner.pan.setValueAtTime(pan, noteStart);

  let destination: AudioNode = voiceGain;
  if (preset.filterType) {
    const filter = ctx.createBiquadFilter();
    filter.type = preset.filterType;
    filter.frequency.setValueAtTime(preset.filterFrequency ?? 1200, noteStart);
    filter.Q.setValueAtTime(preset.filterQ ?? 0.7, noteStart);
    destination.connect(filter);
    destination = filter;
    currentNodes.push(filter);
  }

  const peak = Math.max(0.001, note.velocity * track.volume * 0.45);
  voiceGain.gain.setValueAtTime(0.0001, noteStart);
  voiceGain.gain.linearRampToValueAtTime(peak, noteStart + fadeIn);
  voiceGain.gain.setValueAtTime(peak, noteStart + nominalDur * 0.82);
  voiceGain.gain.linearRampToValueAtTime(0.0001, noteStart + nominalDur + fadeOut);

  destination.connect(panner);
  panner.connect(master);
  currentNodes.push(voiceGain, panner);

  preset.oscillators.forEach((oscDef) => {
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();
    osc.type = oscDef.type;
    osc.frequency.setValueAtTime(freq, noteStart);
    if (oscDef.detune) osc.detune.setValueAtTime(oscDef.detune, noteStart);
    oscGain.gain.setValueAtTime(Math.max(0.0001, oscDef.gain * (1 + preset.transientGain)), noteStart);
    oscGain.gain.exponentialRampToValueAtTime(Math.max(0.0001, oscDef.gain), noteStart + Math.max(0.01, nominalDur * 0.25));
    osc.connect(oscGain);
    oscGain.connect(voiceGain);
    osc.start(noteStart);
    osc.stop(noteEnd);
    currentNodes.push(osc, oscGain);
  });
}

function schedulePresetDrumPattern(
  ctx: AudioContext,
  master: GainNode,
  request: PreviewRequest,
  loopStartSec: number,
  totalDurationSec: number,
) {
  if (!request.drumPattern || !request.drumKit) return;
  if (isRhythmForgeDrumPattern(request.drumPattern)) {
    const matrix = buildVisibleDrumPatternMatrix({ pattern: request.drumPattern, bars: Math.max(1, request.bars) });
    scheduleCustomDrumPattern(ctx, master, {
      ...request,
      customDrumPattern: {
        useCustom: true,
        presetSource: request.drumPattern,
        bars: matrix.bars,
        stepCount: matrix.stepCount,
        laneOrder: [...matrix.laneOrder],
        laneSteps: Object.fromEntries(matrix.laneOrder.map((laneId) => [laneId, [...(matrix.laneSteps[laneId] ?? [])]])) as CanonicalDrumComputerState['laneSteps'],
      },
    }, loopStartSec, totalDurationSec);
    return;
  }
  const machine = createDrumMachine(ctx, master);
  const bars = Math.max(1, request.bars);
  const stepsPerBar = 16;
  const stepDur = totalDurationSec / (bars * stepsPerBar);
  for (let bar = 0; bar < bars; bar += 1) {
    const barOffset = loopStartSec + (bar * totalDurationSec) / bars;
    for (let step = 0; step < stepsPerBar; step += 1) {
      const time = barOffset + step * stepDur;
      machine.schedulePattern(request.drumPattern, step, time, request.drumLevel ?? 0.84, request.drumKit, {
        swing: 0.34,
        edge: 0.52,
        snap: 0.54,
        air: 0.46,
        softness: 0.48,
      });
    }
  }
}

function scheduleCustomDrumPattern(
  ctx: AudioContext,
  master: GainNode,
  request: PreviewRequest,
  loopStartSec: number,
  totalDurationSec: number,
) {
  if (!request.customDrumPattern || !request.drumKit) return;
  const machine = createDrumMachine(ctx, master);
  const totalSteps = Math.max(1, request.customDrumPattern.stepCount);
  const stepDur = totalDurationSec / totalSteps;
  request.customDrumPattern.laneOrder.forEach((laneId) => {
    const values = request.customDrumPattern?.laneSteps[laneId] ?? [];
    values.forEach((value, stepIndex) => {
      if (value <= 0) return;
      const time = loopStartSec + stepIndex * stepDur;
      const gain = (request.drumLevel ?? 0.84) * (value >= 0.95 ? 1.0 : value >= 0.8 ? 0.84 : 0.62);
      machine.trigger(DRUM_VOICE_TO_MACHINE[laneId], time, gain, request.drumKit!, {
        swing: 0.24,
        edge: laneId === 'hatClosed' || laneId === 'hatOpen' ? 0.58 : 0.46,
        snap: value >= 0.95 ? 0.68 : 0.52,
        air: laneId === 'hatOpen' || laneId === 'clap' ? 0.54 : 0.36,
        softness: laneId === 'kick' ? 0.42 : 0.5,
      });
    });
  });
}

function scheduleDrumPattern(
  ctx: AudioContext,
  master: GainNode,
  request: PreviewRequest,
  loopStartSec: number,
  totalDurationSec: number,
) {
  if (request.customDrumPattern?.useCustom) {
    scheduleCustomDrumPattern(ctx, master, request, loopStartSec, totalDurationSec);
    return;
  }
  schedulePresetDrumPattern(ctx, master, request, loopStartSec, totalDurationSec);
}

export async function startLoopComposerPreview(request: PreviewRequest) {
  stopLoopComposerPreview();
  const ctx = getContext();
  if (ctx.state === 'suspended') await ctx.resume();
  const token = ++currentToken;
  const totalSteps = totalComposerSteps(request.composer);
  const totalDurationSec = Math.max(0.25, (Math.max(1, request.bars) * 4 * 60) / Math.max(40, request.bpm));
  const stepDurationSec = totalDurationSec / totalSteps;
  const startTime = ctx.currentTime + 0.03;
  const notes = request.noteId
    ? request.composer.notes.filter((note) => note.id === request.noteId)
    : request.composer.notes.filter((note) => request.trackIds.includes(note.trackId));

  const master = ctx.createGain();
  master.gain.setValueAtTime(0.0001, startTime);
  master.gain.linearRampToValueAtTime(0.8, startTime + 0.02);
  master.connect(ctx.destination);
  currentNodes.push(master);

  notes.forEach((note) => {
    const track = request.composer.tracks.find((entry) => entry.id === note.trackId);
    const pitchStep = request.composer.pitchSteps.find((entry) => entry.id === note.stepId);
    if (!track || !track.enabled || !pitchStep || pitchStep.muted) return;
    scheduleNote(ctx, master, request.composer, note, track, startTime, stepDurationSec);
  });
  scheduleDrumPattern(ctx, master, request, startTime, totalDurationSec);

  const previewDuration = request.noteId
    ? Math.max(0.45, Math.min(2.4, (notes[0]?.lengthSteps ?? 2) * stepDurationSec + ((notes[0]?.fadeOutSteps ?? 1) * stepDurationSec)))
    : totalDurationSec;
  const endTime = startTime + previewDuration;

  const updatePlayhead = () => {
    if (token !== currentToken) return;
    const now = ctx.currentTime;
    if (now >= endTime) {
      request.onPlayhead?.(null);
      request.onEnded?.();
      stopLoopComposerPreview();
      return;
    }
    const rel = Math.max(0, now - startTime);
    request.onPlayhead?.(request.noteId ? (notes[0]?.startStep ?? 0) + rel / stepDurationSec : rel / stepDurationSec);
    if (typeof requestAnimationFrame !== 'undefined') {
      playheadFrame = requestAnimationFrame(updatePlayhead);
    }
  };
  if (typeof requestAnimationFrame !== 'undefined') {
    playheadFrame = requestAnimationFrame(updatePlayhead);
  }
}
