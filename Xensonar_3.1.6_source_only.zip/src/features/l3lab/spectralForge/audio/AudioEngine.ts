import { SpectralData, yToFrequency } from './SpectralData';
import type { AudioSourceAsset } from './AudioImporter';
import { DURATION, buildDefaultGuideMarkers, clampBars, clampGuideSegments, sanitizeGuideMarkers } from '../state/store';
import { getAudioNowSec, getTransportPosition, type TransportClockSpec } from '../../../../core/time/unifiedTime';
import type { SynthMode, WaveformMix } from '../state/store';

interface BeatGuideOptions {
  beatGuideAudible?: boolean;
  beatGuideVolume?: number;
  bars?: number;
  guideSegments?: number;
  guideMarkers?: number[];
  loopPreview?: boolean;
  loopDurationSec?: number;
  playbackRate?: number;
}

// Waveform generator functions
function sawtoothWave(phase: number): number {
  const p = phase % (2 * Math.PI);
  return 2 * (p / (2 * Math.PI)) - 1;
}

function squareWave(phase: number): number {
  return Math.sin(phase) >= 0 ? 1 : -1;
}

function triangleWave(phase: number): number {
  const p = ((phase % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
  return 2 * Math.abs(2 * (p / (2 * Math.PI)) - 1) - 1;
}

function mixedWaveform(phase: number, mix: WaveformMix): number {
  const total = mix.sine + mix.sawtooth + mix.square + mix.triangle;
  if (total < 0.001) return 0;
  const norm = 1 / total;
  let out = 0;
  if (mix.sine > 0) out += mix.sine * norm * Math.sin(phase);
  if (mix.sawtooth > 0) out += mix.sawtooth * norm * sawtoothWave(phase);
  if (mix.square > 0) out += mix.square * norm * squareWave(phase);
  if (mix.triangle > 0) out += mix.triangle * norm * triangleWave(phase);
  return out;
}

/**
 * AudioEngine - Converts spectral data to sound using Web Audio API
 */
export class AudioEngine {
  private ctx: AudioContext | null = null;
  private currentSource: AudioBufferSourceNode | null = null;
  private isPlaying = false;
  private startTime = 0;
  private startOffset = 0;
  private onPositionUpdate: ((pos: number) => void) | null = null;
  private animFrameId: number | null = null;
  private renderedBuffer: AudioBuffer | null = null;
  private playToken = 0;
  private guideNodes: Array<OscillatorNode | GainNode> = [];

  constructor() {}

  private getContext(): AudioContext {
    if (!this.ctx) {
      this.ctx = new AudioContext({ sampleRate: 44100 });
    }
    return this.ctx;
  }

  /**
   * Render spectral data to an AudioBuffer
   */
  async renderToBuffer(
    spectralData: SpectralData,
    synthMode: SynthMode,
    waveformMix: WaveformMix,
    onProgress?: (progress: number) => void
  ): Promise<AudioBuffer> {
    const ctx = this.getContext();
    const sampleRate = ctx.sampleRate;
    const totalSamples = Math.round(DURATION * sampleRate);
    const buffer = ctx.createBuffer(1, totalSamples, sampleRate);
    const output = buffer.getChannelData(0);

    const width = spectralData.width;
    const height = spectralData.height;
    const samplesPerColumn = totalSamples / width;

    if (synthMode === 'additive') {
      await this.renderAdditive(spectralData, output, totalSamples, width, height, samplesPerColumn, sampleRate, waveformMix, onProgress);
    } else if (synthMode === 'granular') {
      await this.renderGranular(spectralData, output, totalSamples, width, height, samplesPerColumn, sampleRate, waveformMix, onProgress);
    } else if (synthMode === 'glyph') {
      await this.renderGlyph(spectralData, output, totalSamples, width, height, samplesPerColumn, sampleRate, waveformMix, onProgress);
    } else {
      await this.renderIFFT(spectralData, output, totalSamples, width, height, samplesPerColumn, sampleRate, onProgress);
    }

    // Normalize
    let maxAmp = 0;
    for (let i = 0; i < totalSamples; i++) {
      maxAmp = Math.max(maxAmp, Math.abs(output[i]));
    }
    if (maxAmp > 0) {
      const gain = 0.8 / maxAmp;
      for (let i = 0; i < totalSamples; i++) {
        output[i] *= gain;
      }
    }

    this.renderedBuffer = buffer;
    return buffer;
  }

  private async renderAdditive(
    spectralData: SpectralData,
    output: Float32Array,
    totalSamples: number,
    width: number,
    height: number,
    _samplesPerColumn: number,
    sampleRate: number,
    waveformMix: WaveformMix,
    onProgress?: (progress: number) => void
  ): Promise<void> {
    const batchSize = 16;
    const phases = new Float32Array(height);

    for (let y = 0; y < height; y += batchSize) {
      const endY = Math.min(y + batchSize, height);

      for (let binY = y; binY < endY; binY++) {
        const freq = yToFrequency(binY, height);
        if (freq < 20 || freq > 20000) continue;

        // Check if this bin has any energy
        let hasEnergy = false;
        for (let x = 0; x < width; x++) {
          if (spectralData.get(x, binY) > 0.001) {
            hasEnergy = true;
            break;
          }
        }
        if (!hasEnergy) continue;

        const phaseInc = (2 * Math.PI * freq) / sampleRate;
        let phase = phases[binY];

        for (let s = 0; s < totalSamples; s++) {
          // Interpolate amplitude from spectral data
          const colF = (s / totalSamples) * width;
          const col0 = Math.floor(colF);
          const col1 = Math.min(col0 + 1, width - 1);
          const t = colF - col0;

          const amp0 = spectralData.get(col0, binY);
          const amp1 = spectralData.get(col1, binY);
          const amp = amp0 + (amp1 - amp0) * t;

          if (amp > 0.001) {
            output[s] += mixedWaveform(phase, waveformMix) * amp * 0.02;
          }
          phase += phaseInc;
        }

        phases[binY] = phase % (2 * Math.PI);
      }

      if (onProgress) {
        onProgress(endY / height);
      }

      // Yield to UI thread
      await new Promise(r => setTimeout(r, 0));
    }
  }

  /**
   * Granular synthesis - grain duration is controlled by the grain layer
   * Short grains → noise-like texture
   * Long grains → tonal, smooth
   */
  private async renderGranular(
    spectralData: SpectralData,
    output: Float32Array,
    totalSamples: number,
    width: number,
    height: number,
    samplesPerColumn: number,
    sampleRate: number,
    waveformMix: WaveformMix,
    onProgress?: (progress: number) => void
  ): Promise<void> {
    // Process in column batches
    const colBatch = 32;

    for (let xStart = 0; xStart < width; xStart += colBatch) {
      const xEnd = Math.min(xStart + colBatch, width);

      for (let x = xStart; x < xEnd; x++) {
        const colStartSample = Math.round((x / width) * totalSamples);

        for (let y = 0; y < height; y++) {
          const amp = spectralData.get(x, y);
          if (amp < 0.01) continue;

          const freq = yToFrequency(y, height);
          if (freq < 20 || freq > 20000) continue;

          // Get grain duration from grain layer
          const grainParam = spectralData.getGrain(x, y);
          // Map 0-1 to grain duration: 0 = 1ms (noisy), 1 = 150ms (tonal)
          const grainDuration = 0.001 + grainParam * grainParam * 0.149;
          const grainSamples = Math.max(4, Math.round(grainDuration * sampleRate));

          // Number of overlapping grains (more for longer durations = smoother)
          const numGrains = Math.max(1, Math.round(1 + grainParam * 2));

          for (let g = 0; g < numGrains; g++) {
            // Scatter grain within the column's time window
            const grainOffset = Math.round(Math.random() * samplesPerColumn);
            const grainStart = colStartSample + grainOffset;

            // Random initial phase for natural sound
            const randomPhase = Math.random() * 2 * Math.PI;
            const phaseInc = (2 * Math.PI * freq) / sampleRate;

            // Slight pitch randomization for short grains (adds noise character)
            const pitchJitter = grainParam < 0.3 ? (1 + (Math.random() - 0.5) * 0.1 * (1 - grainParam * 3)) : 1;

            for (let s = 0; s < grainSamples; s++) {
              const idx = grainStart + s;
              if (idx < 0 || idx >= totalSamples) continue;

              // Hann window
              const windowVal = 0.5 * (1 - Math.cos((2 * Math.PI * s) / grainSamples));
              const phase = randomPhase + phaseInc * s * pitchJitter;
              output[idx] += mixedWaveform(phase, waveformMix) * amp * windowVal * 0.015 / numGrains;
            }
          }
        }
      }

      if (onProgress) {
        onProgress(xEnd / width);
        await new Promise(r => setTimeout(r, 0));
      }
    }
  }

  private async renderGlyph(
    spectralData: SpectralData,
    output: Float32Array,
    totalSamples: number,
    width: number,
    height: number,
    samplesPerColumn: number,
    sampleRate: number,
    waveformMix: WaveformMix,
    onProgress?: (progress: number) => void
  ): Promise<void> {
    const colBatch = 24;
    const maxPeaksPerColumn = 5;
    const phases = new Float32Array(height);
    const columnEnergy = new Float32Array(width);

    for (let x = 0; x < width; x++) {
      let energy = 0;
      for (let y = 0; y < height; y++) energy += spectralData.get(x, y);
      columnEnergy[x] = energy / Math.max(1, height);
    }

    for (let xStart = 0; xStart < width; xStart += colBatch) {
      const xEnd = Math.min(xStart + colBatch, width);
      for (let x = xStart; x < xEnd; x++) {
        const columnTime = Math.round((x / width) * totalSamples);
        const prev = x > 0 ? columnEnergy[x - 1] : 0;
        const next = x < width - 1 ? columnEnergy[x + 1] : 0;
        const transient = Math.max(0, columnEnergy[x] - Math.max(prev, next) * 0.82);
        const peaks: Array<{ y: number; amp: number }> = [];

        for (let y = 1; y < height - 1; y++) {
          const amp = spectralData.get(x, y);
          if (amp < 0.05) continue;
          const prevAmp = spectralData.get(x, y - 1);
          const nextAmp = spectralData.get(x, y + 1);
          if (amp < prevAmp || amp < nextAmp) continue;
          peaks.push({ y, amp: amp + transient * 0.55 + spectralData.getGrain(x, y) * 0.06 });
        }

        peaks.sort((a, b) => b.amp - a.amp);
        peaks.length = Math.min(maxPeaksPerColumn, peaks.length);
        if (!peaks.length) continue;

        for (let p = 0; p < peaks.length; p++) {
          const y = peaks[p].y;
          const ampAtPeak = spectralData.get(x, y);
          const freq = yToFrequency(y, height);
          if (freq < 20 || freq > 18000) continue;
          const grain = spectralData.getGrain(x, y);
          const durSec = 0.014 + grain * grain * 0.18 + transient * 0.06;
          const voiceSamples = Math.max(8, Math.round(durSec * sampleRate));
          const localStart = columnTime + Math.round((p / Math.max(1, peaks.length)) * samplesPerColumn * 0.55);
          const phaseInc = (2 * Math.PI * freq) / sampleRate;
          let phase = phases[y] || Math.random() * Math.PI * 2;
          const brightness = Math.min(1, ampAtPeak * (0.75 + transient * 1.4));
          const gain = 0.014 + ampAtPeak * 0.055;

          for (let s = 0; s < voiceSamples; s++) {
            const idxOut = localStart + s;
            if (idxOut < 0 || idxOut >= totalSamples) break;
            const envT = s / Math.max(1, voiceSamples - 1);
            const env = Math.sin(Math.min(1, envT) * Math.PI) * Math.exp(-envT * (2.8 - grain * 1.1));
            const shimmer = Math.sin(envT * Math.PI * (1.5 + grain * 2.4)) * 0.12 * brightness;
            output[idxOut] += mixedWaveform(phase + shimmer, waveformMix) * env * gain * (1 - p * 0.12);
            phase += phaseInc * (1 + transient * 0.015);
          }
          phases[y] = phase % (2 * Math.PI);
        }
      }

      if (onProgress) onProgress(xEnd / width);
      await new Promise(r => setTimeout(r, 0));
    }
  }

  private async renderIFFT(
    spectralData: SpectralData,
    output: Float32Array,
    totalSamples: number,
    width: number,
    height: number,
    samplesPerColumn: number,
    sampleRate: number,
    onProgress?: (progress: number) => void
  ): Promise<void> {
    const fftSize = 2048;
    const hopSize = Math.round(samplesPerColumn);

    const window = new Float32Array(fftSize);
    for (let i = 0; i < fftSize; i++) {
      window[i] = 0.5 * (1 - Math.cos((2 * Math.PI * i) / (fftSize - 1)));
    }

    for (let x = 0; x < width; x++) {
      const real = new Float32Array(fftSize);
      const imag = new Float32Array(fftSize);

      for (let y = 0; y < height; y++) {
        const amp = spectralData.get(x, y);
        if (amp < 0.001) continue;

        const freq = yToFrequency(y, height);
        const bin = Math.round((freq / sampleRate) * fftSize);
        if (bin > 0 && bin < fftSize / 2) {
          const phase = Math.random() * 2 * Math.PI;
          real[bin] += amp * Math.cos(phase);
          imag[bin] += amp * Math.sin(phase);
          real[fftSize - bin] = real[bin];
          imag[fftSize - bin] = -imag[bin];
        }
      }

      const timeDomain = this.idft(real, imag, fftSize);

      const startSample = Math.round(x * samplesPerColumn);
      for (let i = 0; i < fftSize && startSample + i < totalSamples; i++) {
        output[startSample + i] += timeDomain[i] * window[i] * 0.5;
      }

      if (onProgress && x % 64 === 0) {
        onProgress(x / width);
        await new Promise(r => setTimeout(r, 0));
      }
    }

    void sampleRate; void hopSize;
  }

  private idft(real: Float32Array, imag: Float32Array, N: number): Float32Array {
    const output = new Float32Array(N);

    const activeBins: number[] = [];
    for (let k = 0; k < N; k++) {
      if (Math.abs(real[k]) > 0.0001 || Math.abs(imag[k]) > 0.0001) {
        activeBins.push(k);
      }
    }

    for (let n = 0; n < N; n++) {
      let sum = 0;
      for (const k of activeBins) {
        const angle = (2 * Math.PI * k * n) / N;
        sum += real[k] * Math.cos(angle) - imag[k] * Math.sin(angle);
      }
      output[n] = sum / N;
    }

    return output;
  }

  private async playBufferInternal(
    buffer: AudioBuffer,
    durationSec: number,
    fromPosition: number,
    onPosition?: (pos: number) => void,
    onEnd?: () => void,
    options?: {
      playbackRate?: number;
      loopPreview?: boolean;
      beatGuide?: BeatGuideOptions;
    }
  ): Promise<void> {
    this.stop();

    const ctx = this.getContext();
    if (ctx.state === 'suspended') {
      await ctx.resume();
    }

    this.onPositionUpdate = onPosition || null;

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);

    const playbackRate = Math.max(0.05, options?.playbackRate ?? 1);
    const loopPreview = !!options?.loopPreview;
    source.playbackRate.setValueAtTime(playbackRate, ctx.currentTime);
    source.loop = loopPreview;
    source.loopStart = 0;
    source.loopEnd = durationSec;

    this.startOffset = Math.max(0, Math.min(durationSec, fromPosition * durationSec));
    this.startTime = getAudioNowSec(ctx);
    this.isPlaying = true;
    this.currentSource = source;
    const token = ++this.playToken;
    const clockSpec: TransportClockSpec = {
      startTimeSec: this.startTime,
      startOffsetSec: this.startOffset,
      durationSec,
      playbackRate,
      loop: loopPreview,
    };

    this.onPositionUpdate?.(fromPosition);
    source.start(0, this.startOffset);

    if (options?.beatGuide?.beatGuideAudible) {
      this.scheduleBeatGuide(
        ctx,
        this.startTime,
        this.startOffset,
        options.beatGuide.bars ?? 4,
        options.beatGuide.guideSegments ?? 4,
        options.beatGuide.guideMarkers ?? buildDefaultGuideMarkers(4),
        Math.max(0.05, options.beatGuide.loopDurationSec ?? (durationSec / playbackRate)),
        loopPreview,
        Math.max(0, Math.min(1, options.beatGuide.beatGuideVolume ?? 0.35))
      );
    }

    source.onended = () => {
      if (token !== this.playToken) return;
      this.isPlaying = false;
      if (this.animFrameId) cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
      this.onPositionUpdate?.(1);
      onEnd?.();
    };

    const updatePosition = () => {
      if (!this.isPlaying || token !== this.playToken) return;
      const pos = getTransportPosition(clockSpec, getAudioNowSec(ctx));
      this.onPositionUpdate?.(pos);
      if (!loopPreview && pos >= 1) {
        return;
      }
      this.animFrameId = requestAnimationFrame(updatePosition);
    };
    this.animFrameId = requestAnimationFrame(updatePosition);
  }

  /**
   * Play from a position (0-1)
   */
  async play(
    spectralData: SpectralData,
    synthMode: SynthMode,
    waveformMix: WaveformMix,
    fromPosition: number = 0,
    onPosition?: (pos: number) => void,
    onEnd?: () => void,
    onProgress?: (progress: number) => void,
    beatGuide?: BeatGuideOptions
  ): Promise<void> {
    if (!this.renderedBuffer) {
      this.renderedBuffer = await this.renderToBuffer(spectralData, synthMode, waveformMix, onProgress);
    }

    await this.playBufferInternal(
      this.renderedBuffer,
      DURATION,
      fromPosition,
      onPosition,
      onEnd,
      {
        playbackRate: Math.max(0.05, beatGuide?.playbackRate ?? 1),
        loopPreview: !!beatGuide?.loopPreview,
        beatGuide,
      }
    );
  }

  async playSourceAsset(
    sourceAsset: AudioSourceAsset,
    previewMode: 'window' | 'full' = 'window',
    fromPosition: number = 0,
    onPosition?: (pos: number) => void,
    onEnd?: () => void,
  ): Promise<void> {
    const ctx = this.getContext();
    const sampleRate = sourceAsset.sampleRate;
    const startSec = previewMode === 'full' ? 0 : sourceAsset.importStartSec;
    const durationSec = previewMode === 'full'
      ? Math.max(0.05, sourceAsset.originalDuration)
      : Math.max(0.05, sourceAsset.importDurationSec);
    const startSample = Math.max(0, Math.floor(startSec * sampleRate));
    const sampleLength = Math.max(1, Math.min(sourceAsset.monoSamples.length - startSample, Math.floor(durationSec * sampleRate)));
    const buffer = ctx.createBuffer(1, sampleLength, sampleRate);
    buffer.copyToChannel(Float32Array.from(sourceAsset.monoSamples.subarray(startSample, startSample + sampleLength)), 0, 0);
    await this.playBufferInternal(buffer, sampleLength / sampleRate, fromPosition, onPosition, onEnd, { playbackRate: 1, loopPreview: false });
  }

  stop(): void {
    this.playToken++;
    this.stopBeatGuide();
    if (this.currentSource) {
      try { this.currentSource.stop(); } catch { /* noop */ }
      this.currentSource = null;
    }
    this.isPlaying = false;
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
  }

  /** Invalidate rendered buffer when data changes */
  invalidateBuffer(): void {
    this.renderedBuffer = null;
  }

  private stopBeatGuide(): void {
    for (const node of this.guideNodes) {
      try { node.disconnect(); } catch {}
      if ('stop' in node && typeof (node as OscillatorNode).stop === 'function') {
        try { (node as OscillatorNode).stop(); } catch {}
      }
    }
    this.guideNodes = [];
  }

  private scheduleBeatGuide(ctx: AudioContext, startTime: number, startOffset: number, bars: number, guideSegments: number, guideMarkers: number[], loopDurationSec: number, loopPreview: boolean, guideVolume: number): void {
    this.stopBeatGuide();
    const safeBars = clampBars(bars);
    const safeSegments = clampGuideSegments(guideSegments);
    const safeMarkers = sanitizeGuideMarkers(guideMarkers, safeSegments);
    const cycleDuration = Math.max(0.05, loopDurationSec);
    const effectiveStartInCycle = Math.max(0, Math.min(cycleDuration, (startOffset / DURATION) * cycleDuration));
    const clickLead = 0.004;
    const barDuration = cycleDuration / safeBars;
    const events: { whenInCycle: number; isBarStart: boolean }[] = [];

    for (let bar = 0; bar < safeBars; bar++) {
      const barStart = bar * barDuration;
      events.push({ whenInCycle: barStart, isBarStart: true });
      for (const marker of safeMarkers) {
        events.push({ whenInCycle: barStart + marker * barDuration, isBarStart: false });
      }
    }

    events.sort((a, b) => a.whenInCycle - b.whenInCycle);

    const horizon = loopPreview ? Math.min(120, Math.max(cycleDuration * 4, 20)) : cycleDuration;
    const repetitions = loopPreview ? Math.max(2, Math.ceil((horizon + effectiveStartInCycle) / cycleDuration)) : 1;

    for (let cycle = 0; cycle < repetitions; cycle++) {
      for (const event of events) {
        const absoluteTimeInGuide = cycle * cycleDuration + event.whenInCycle;
        if (absoluteTimeInGuide + 0.001 < effectiveStartInCycle) continue;
        const when = startTime + Math.max(0, absoluteTimeInGuide - effectiveStartInCycle);
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const freq = event.isBarStart ? 1320 : 920;
        const amp = (event.isBarStart ? 0.075 : 0.04) * guideVolume;
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, when);
        gain.gain.setValueAtTime(0.0001, when);
        gain.gain.exponentialRampToValueAtTime(Math.max(0.0001, amp), when + 0.001);
        gain.gain.exponentialRampToValueAtTime(0.0001, when + clickLead + 0.018);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(when);
        osc.stop(when + clickLead + 0.03);
        this.guideNodes.push(osc, gain);
      }
    }
  }

  /** Play a short preview of a specific column with waveform mix */
  async previewColumn(
    spectralData: SpectralData,
    columnX: number,
    waveformMix: WaveformMix,
    durationMs: number = 200
  ): Promise<void> {
    const ctx = this.getContext();
    if (ctx.state === 'suspended') await ctx.resume();

    const height = spectralData.height;
    const now = ctx.currentTime;
    const dur = durationMs / 1000;

    const sampleRate = ctx.sampleRate;
    const numSamples = Math.round(dur * sampleRate);
    const buffer = ctx.createBuffer(1, numSamples, sampleRate);
    const output = buffer.getChannelData(0);

    // Collect active frequencies
    const freqAmps: { freq: number; amp: number }[] = [];
    for (let y = 0; y < height; y++) {
      const amp = spectralData.get(columnX, y);
      if (amp < 0.02) continue;
      const freq = yToFrequency(y, height);
      if (freq < 20 || freq > 20000) continue;
      freqAmps.push({ freq, amp });
      if (freqAmps.length >= 64) break;
    }

    // Render mixed waveform
    for (const fa of freqAmps) {
      const phaseInc = (2 * Math.PI * fa.freq) / sampleRate;
      let phase = 0;
      for (let i = 0; i < numSamples; i++) {
        // Envelope: fade out
        const env = 1 - (i / numSamples);
        output[i] += mixedWaveform(phase, waveformMix) * fa.amp * 0.03 * env;
        phase += phaseInc;
      }
    }

    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.start(now);
    source.stop(now + dur + 0.05);
  }

  /**
   * Export to WAV file
   */
  async exportWAV(
    spectralData: SpectralData,
    synthMode: SynthMode,
    waveformMix: WaveformMix,
    onProgress?: (progress: number) => void
  ): Promise<Blob> {
    const buffer = await this.renderToBuffer(spectralData, synthMode, waveformMix, onProgress);
    const channelData = buffer.getChannelData(0);
    return this.encodeWAV(channelData, buffer.sampleRate);
  }

  private encodeWAV(samples: Float32Array, sampleRate: number): Blob {
    const length = samples.length;
    const buffer = new ArrayBuffer(44 + length * 2);
    const view = new DataView(buffer);

    const writeString = (offset: number, str: string) => {
      for (let i = 0; i < str.length; i++) {
        view.setUint8(offset + i, str.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length * 2, true);

    for (let i = 0; i < length; i++) {
      const s = Math.max(-1, Math.min(1, samples[i]));
      view.setInt16(44 + i * 2, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }

    return new Blob([buffer], { type: 'audio/wav' });
  }
}

// Singleton
export const audioEngine = new AudioEngine();
